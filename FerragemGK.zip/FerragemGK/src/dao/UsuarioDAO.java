package dao;

import conexao.Conexao;
import model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class UsuarioDAO {

    public Usuario autenticar(String login, String senha) {
        String sql = "SELECT id_usuario, nome, login, senha, nivel, ativo "
                + "FROM usuario "
                + "WHERE login = ? AND senha = ? AND ativo = TRUE";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, login);
            stmt.setString(2, senha);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = new Usuario();
                    usuario.setIdUsuario(rs.getInt("id_usuario"));
                    usuario.setNome(rs.getString("nome"));
                    usuario.setLogin(rs.getString("login"));
                    usuario.setSenha(rs.getString("senha"));
                    usuario.setNivel(rs.getString("nivel"));
                    usuario.setAtivo(rs.getBoolean("ativo"));
                    return usuario;
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao autenticar usuário.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }

    public boolean inserir(Usuario usuario) {
        String sql = "INSERT INTO usuario (nome, login, senha, nivel, ativo) VALUES (?, ?, ?, ?, ?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            preencherParametros(stmt, usuario);
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    usuario.setIdUsuario(rs.getInt(1));
                }
            }
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao cadastrar usuário.\nVerifique se o login já não está em uso.\n"
                            + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean alterar(Usuario usuario) {
        String sql = "UPDATE usuario SET nome = ?, login = ?, senha = ?, nivel = ?, ativo = ? "
                + "WHERE id_usuario = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            preencherParametros(stmt, usuario);
            stmt.setInt(6, usuario.getIdUsuario());
            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao alterar usuário.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean excluir(int idUsuario) {
        String sql = "DELETE FROM usuario WHERE id_usuario = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idUsuario);
            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao excluir usuário.\nVerifique se ele não possui compras/vendas "
                            + "vinculadas.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public List<Usuario> listarTodos() {
        return pesquisar(null, null);
    }

    public List<Usuario> pesquisar(String filtro, String texto) {
        List<Usuario> usuarios = new ArrayList<>();

        String coluna = "nome";
        if (filtro != null) {
            switch (filtro.toUpperCase()) {
                case "LOGIN":
                    coluna = "login";
                    break;
                case "ID":
                    coluna = "CAST(id_usuario AS VARCHAR)";
                    break;
                default:
                    coluna = "nome";
            }
        }

        boolean temFiltro = texto != null && !texto.trim().isEmpty();

        String sql = "SELECT id_usuario, nome, login, senha, nivel, ativo FROM usuario ";
        if (temFiltro) {
            sql += "WHERE UPPER(" + coluna + ") LIKE UPPER(?) ";
        }
        sql += "ORDER BY nome";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            if (temFiltro) {
                stmt.setString(1, "%" + texto.trim() + "%");
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    usuarios.add(mapear(rs));
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao pesquisar usuários.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return usuarios;
    }

    public boolean loginJaExiste(String login, Integer idIgnorar) {
        String sql = "SELECT id_usuario FROM usuario WHERE login = ?"
                + (idIgnorar != null ? " AND id_usuario <> ?" : "");

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, login);
            if (idIgnorar != null) {
                stmt.setInt(2, idIgnorar);
            }
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao verificar login.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return true; 
        }
    }

    private void preencherParametros(PreparedStatement stmt, Usuario usuario) throws SQLException {
        stmt.setString(1, usuario.getNome());
        stmt.setString(2, usuario.getLogin());
        stmt.setString(3, usuario.getSenha());
        stmt.setString(4, usuario.getNivel());
        stmt.setBoolean(5, usuario.isAtivo());
    }

    private Usuario mapear(ResultSet rs) throws SQLException {
        Usuario usuario = new Usuario();
        usuario.setIdUsuario(rs.getInt("id_usuario"));
        usuario.setNome(rs.getString("nome"));
        usuario.setLogin(rs.getString("login"));
        usuario.setSenha(rs.getString("senha"));
        usuario.setNivel(rs.getString("nivel"));
        usuario.setAtivo(rs.getBoolean("ativo"));
        return usuario;
    }
}