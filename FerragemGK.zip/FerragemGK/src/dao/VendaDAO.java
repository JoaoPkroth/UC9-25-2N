package dao;

import conexao.Conexao;
import model.ProdutoVenda;
import model.Venda;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class VendaDAO {

    public void inserir(Connection conexao, Venda venda) throws SQLException {
        String sql = "INSERT INTO venda (id_cliente, id_usuario, data_venda, forma_pagamento, "
                + "quantidade_parcelas, valor_total, status) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, venda.getIdCliente());
            stmt.setInt(2, venda.getIdUsuario());
            stmt.setDate(3, Date.valueOf(venda.getDataVenda()));
            stmt.setString(4, venda.getFormaPagamento());
            stmt.setInt(5, venda.getQuantidadeParcelas());
            stmt.setBigDecimal(6, venda.getValorTotal());
            stmt.setString(7, venda.getStatus());
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    venda.setIdVenda(rs.getInt(1));
                }
            }
        }
    }

    public void inserirItens(Connection conexao, Venda venda) throws SQLException {
        String sql = "INSERT INTO produtos_venda (id_venda, id_produto, quantidade, valor_unitario, subtotal) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            for (ProdutoVenda item : venda.getItens()) {
                stmt.setInt(1, venda.getIdVenda());
                stmt.setInt(2, item.getIdProduto());
                stmt.setBigDecimal(3, item.getQuantidade());
                stmt.setBigDecimal(4, item.getValorUnitario());
                stmt.setBigDecimal(5, item.getSubtotal());
                stmt.addBatch();
            }
            stmt.executeBatch();
        }
    }

    public void baixarEstoque(Connection conexao, ProdutoVenda item) throws SQLException {
        String sql = "UPDATE produto SET estoque = estoque - ? WHERE id_produto = ? AND estoque >= ?";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setBigDecimal(1, item.getQuantidade());
            stmt.setInt(2, item.getIdProduto());
            stmt.setBigDecimal(3, item.getQuantidade());

            int linhasAfetadas = stmt.executeUpdate();
            if (linhasAfetadas == 0) {
                throw new SQLException("Estoque insuficiente para o produto \""
                        + item.getDescricaoProduto() + "\".");
            }
        }
    }
    
    public void devolverEstoque(Connection conexao, ProdutoVenda item) throws SQLException {
        String sql = "UPDATE produto SET estoque = estoque + ? WHERE id_produto = ?";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setBigDecimal(1, item.getQuantidade());
            stmt.setInt(2, item.getIdProduto());
            stmt.executeUpdate();
        }
    }

    public void cancelar(Connection conexao, int idVenda) throws SQLException {
        String sql = "UPDATE venda SET status = 'CANCELADA' WHERE id_venda = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, idVenda);
            stmt.executeUpdate();
        }
    }

    public List<Venda> pesquisar(String filtro, String texto) {
        List<Venda> vendas = new ArrayList<>();

        String sql = "SELECT v.id_venda, v.id_cliente, c.nome, v.id_usuario, v.data_venda, "
                + "v.forma_pagamento, v.quantidade_parcelas, v.valor_total, v.status "
                + "FROM venda v "
                + "JOIN cliente c ON c.id_cliente = v.id_cliente ";

        String filtroUpper = filtro == null ? "TODAS" : filtro.toUpperCase();
        boolean temTexto = texto != null && !texto.trim().isEmpty();

        switch (filtroUpper) {
            case "FINALIZADAS":
                sql += "WHERE v.status = 'FINALIZADA' ";
                break;
            case "CANCELADAS":
                sql += "WHERE v.status = 'CANCELADA' ";
                break;
            case "CLIENTE":
                sql += temTexto ? "WHERE UPPER(c.nome) LIKE UPPER(?) " : "";
                break;
            default:
                // TODAS - sem filtro
                break;
        }

        sql += "ORDER BY v.data_venda DESC, v.id_venda DESC";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            if ("CLIENTE".equals(filtroUpper) && temTexto) {
                stmt.setString(1, "%" + texto.trim() + "%");
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    vendas.add(mapear(rs));
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao pesquisar vendas.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return vendas;
    }

    public List<ProdutoVenda> listarItens(int idVenda) {
        List<ProdutoVenda> itens = new ArrayList<>();
        String sql = "SELECT pv.id_produto_venda, pv.id_venda, pv.id_produto, p.descricao, "
                + "pv.quantidade, pv.valor_unitario, pv.subtotal "
                + "FROM produtos_venda pv "
                + "JOIN produto p ON p.id_produto = pv.id_produto "
                + "WHERE pv.id_venda = ? "
                + "ORDER BY pv.id_produto_venda";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idVenda);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    ProdutoVenda item = new ProdutoVenda();
                    item.setIdProdutoVenda(rs.getInt("id_produto_venda"));
                    item.setIdVenda(rs.getInt("id_venda"));
                    item.setIdProduto(rs.getInt("id_produto"));
                    item.setDescricaoProduto(rs.getString("descricao"));
                    item.setQuantidade(rs.getBigDecimal("quantidade"));
                    item.setValorUnitario(rs.getBigDecimal("valor_unitario"));
                    item.setSubtotal(rs.getBigDecimal("subtotal"));
                    itens.add(item);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao listar os itens da venda.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return itens;
    }
    
    public List<Venda> listarTodas() {
        List<Venda> vendas = new ArrayList<>();
        String sql = "SELECT v.id_venda, v.id_cliente, c.nome, v.id_usuario, v.data_venda, "
                + "v.forma_pagamento, v.quantidade_parcelas, v.valor_total, v.status "
                + "FROM venda v "
                + "JOIN cliente c ON c.id_cliente = v.id_cliente "
                + "ORDER BY v.data_venda DESC, v.id_venda DESC";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                vendas.add(mapear(rs));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao listar vendas.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return vendas;
    }

    private Venda mapear(ResultSet rs) throws SQLException {
        Venda venda = new Venda();
        venda.setIdVenda(rs.getInt("id_venda"));
        venda.setIdCliente(rs.getInt("id_cliente"));
        venda.setNomeCliente(rs.getString("nome"));
        venda.setIdUsuario(rs.getInt("id_usuario"));
        venda.setDataVenda(rs.getDate("data_venda").toLocalDate());
        venda.setFormaPagamento(rs.getString("forma_pagamento"));
        venda.setQuantidadeParcelas(rs.getInt("quantidade_parcelas"));
        venda.setValorTotal(rs.getBigDecimal("valor_total"));
        venda.setStatus(rs.getString("status"));
        return venda;
    }
}