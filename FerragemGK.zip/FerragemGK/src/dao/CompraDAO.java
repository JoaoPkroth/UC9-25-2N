package dao;

import conexao.Conexao;
import model.Compra;
import model.ProdutoCompra;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class CompraDAO {

    public void inserir(Connection conexao, Compra compra) throws SQLException {
        String sql = "INSERT INTO compra (id_fornecedor, id_usuario, data_compra, forma_pagamento, "
                + "quantidade_parcelas, valor_total, status) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, compra.getIdFornecedor());
            stmt.setInt(2, compra.getIdUsuario());
            stmt.setDate(3, Date.valueOf(compra.getDataCompra()));
            stmt.setString(4, compra.getFormaPagamento());
            stmt.setInt(5, compra.getQuantidadeParcelas());
            stmt.setBigDecimal(6, compra.getValorTotal());
            stmt.setString(7, compra.getStatus());
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    compra.setIdCompra(rs.getInt(1));
                }
            }
        }
    }

    public void inserirItens(Connection conexao, Compra compra) throws SQLException {
        String sql = "INSERT INTO produtos_compra (id_compra, id_produto, quantidade, valor_unitario, subtotal) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            for (ProdutoCompra item : compra.getItens()) {
                stmt.setInt(1, compra.getIdCompra());
                stmt.setInt(2, item.getIdProduto());
                stmt.setBigDecimal(3, item.getQuantidade());
                stmt.setBigDecimal(4, item.getValorUnitario());
                stmt.setBigDecimal(5, item.getSubtotal());
                stmt.addBatch();
            }
            stmt.executeBatch();
        }
    }

    public void atualizarEstoque(Connection conexao, ProdutoCompra item) throws SQLException {
        String sql = "UPDATE produto SET estoque = estoque + ? WHERE id_produto = ?";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setBigDecimal(1, item.getQuantidade());
            stmt.setInt(2, item.getIdProduto());
            stmt.executeUpdate();
        }
    }

    public void reverterEstoque(Connection conexao, ProdutoCompra item) throws SQLException {
        String sql = "UPDATE produto SET estoque = GREATEST(estoque - ?, 0) WHERE id_produto = ?";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setBigDecimal(1, item.getQuantidade());
            stmt.setInt(2, item.getIdProduto());
            stmt.executeUpdate();
        }
    }

    public List<Compra> listarTodas() {
        List<Compra> compras = new ArrayList<>();
        String sql = "SELECT c.id_compra, c.id_fornecedor, f.nome_fantasia, f.razao_social, c.id_usuario, "
                + "c.data_compra, c.forma_pagamento, c.quantidade_parcelas, c.valor_total, c.status "
                + "FROM compra c "
                + "JOIN fornecedor f ON f.id_fornecedor = c.id_fornecedor "
                + "ORDER BY c.data_compra DESC, c.id_compra DESC";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                compras.add(mapear(rs));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao listar compras.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return compras;
    }

    public List<Compra> pesquisar(String filtro, String texto) {
        List<Compra> compras = new ArrayList<>();

        String sql = "SELECT c.id_compra, c.id_fornecedor, f.nome_fantasia, f.razao_social, c.id_usuario, "
                + "c.data_compra, c.forma_pagamento, c.quantidade_parcelas, c.valor_total, c.status "
                + "FROM compra c "
                + "JOIN fornecedor f ON f.id_fornecedor = c.id_fornecedor ";

        String filtroUpper = filtro == null ? "TODAS" : filtro.toUpperCase();
        boolean temTexto = texto != null && !texto.trim().isEmpty();

        switch (filtroUpper) {
            case "FINALIZADAS":
                sql += "WHERE c.status = 'FINALIZADA' ";
                break;
            case "CANCELADAS":
                sql += "WHERE c.status = 'CANCELADA' ";
                break;
            case "FORNECEDOR":
                sql += temTexto ? "WHERE UPPER(f.razao_social) LIKE UPPER(?) OR UPPER(f.nome_fantasia) LIKE UPPER(?) " : "";
                break;
            default:
                // TODAS - sem filtro
                break;
        }

        sql += "ORDER BY c.data_compra DESC, c.id_compra DESC";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            if ("FORNECEDOR".equals(filtroUpper) && temTexto) {
                stmt.setString(1, "%" + texto.trim() + "%");
                stmt.setString(2, "%" + texto.trim() + "%");
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    compras.add(mapear(rs));
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao pesquisar compras.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return compras;
    }

    public List<ProdutoCompra> listarItens(int idCompra) {
        List<ProdutoCompra> itens = new ArrayList<>();
        String sql = "SELECT pc.id_produto_compra, pc.id_compra, pc.id_produto, p.descricao, "
                + "pc.quantidade, pc.valor_unitario, pc.subtotal "
                + "FROM produtos_compra pc "
                + "JOIN produto p ON p.id_produto = pc.id_produto "
                + "WHERE pc.id_compra = ? "
                + "ORDER BY pc.id_produto_compra";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idCompra);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    ProdutoCompra item = new ProdutoCompra();
                    item.setIdProdutoCompra(rs.getInt("id_produto_compra"));
                    item.setIdCompra(rs.getInt("id_compra"));
                    item.setIdProduto(rs.getInt("id_produto"));
                    item.setDescricaoProduto(rs.getString("descricao"));
                    item.setQuantidade(rs.getBigDecimal("quantidade"));
                    item.setValorUnitario(rs.getBigDecimal("valor_unitario"));
                    item.setSubtotal(rs.getBigDecimal("subtotal"));
                    itens.add(item);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao listar os itens da compra.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return itens;
    }

    public void cancelar(Connection conexao, int idCompra) throws SQLException {
        String sql = "UPDATE compra SET status = 'CANCELADA' WHERE id_compra = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, idCompra);
            stmt.executeUpdate();
        }
    }

    private Compra mapear(ResultSet rs) throws SQLException {
        Compra compra = new Compra();
        compra.setIdCompra(rs.getInt("id_compra"));
        compra.setIdFornecedor(rs.getInt("id_fornecedor"));
        String fantasia = rs.getString("nome_fantasia");
        compra.setNomeFornecedor(fantasia != null && !fantasia.isEmpty() ? fantasia : rs.getString("razao_social"));
        compra.setIdUsuario(rs.getInt("id_usuario"));
        compra.setDataCompra(rs.getDate("data_compra").toLocalDate());
        compra.setFormaPagamento(rs.getString("forma_pagamento"));
        compra.setQuantidadeParcelas(rs.getInt("quantidade_parcelas"));
        compra.setValorTotal(rs.getBigDecimal("valor_total"));
        compra.setStatus(rs.getString("status"));
        return compra;
    }
}