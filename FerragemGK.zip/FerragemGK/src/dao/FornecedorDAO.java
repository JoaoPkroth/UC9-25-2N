package dao;

import conexao.Conexao;
import model.Fornecedor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class FornecedorDAO {

    public boolean inserir(Fornecedor fornecedor) {
        String sql = "INSERT INTO fornecedor (razao_social, nome_fantasia, cnpj, telefone, email, "
                + "endereco, cidade, uf, cep, ativo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            preencherParametros(stmt, fornecedor);
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    fornecedor.setIdFornecedor(rs.getInt(1));
                }
            }
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao cadastrar fornecedor.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean alterar(Fornecedor fornecedor) {
        String sql = "UPDATE fornecedor SET razao_social = ?, nome_fantasia = ?, cnpj = ?, "
                + "telefone = ?, email = ?, endereco = ?, cidade = ?, uf = ?, cep = ?, ativo = ? "
                + "WHERE id_fornecedor = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            preencherParametros(stmt, fornecedor);
            stmt.setInt(11, fornecedor.getIdFornecedor());
            int linhasAfetadas = stmt.executeUpdate();

            if (linhasAfetadas != 1) {
                JOptionPane.showMessageDialog(null,
                        "Nenhum fornecedor foi alterado. O registro selecionado pode não existir mais.",
                        "Atenção", JOptionPane.WARNING_MESSAGE);
                return false;
            }
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao alterar fornecedor.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean excluir(int idFornecedor) {
        String sqlVerificarVinculo = "SELECT 1 FROM compra WHERE id_fornecedor = ? LIMIT 1";
        String sqlExcluir = "DELETE FROM fornecedor WHERE id_fornecedor = ?";

        try (Connection conexao = Conexao.conectar()) {

            // Qualquer compra vinculada bloqueia a exclusão, independentemente do status.
            // Portanto ABERTA, FINALIZADA e CANCELADA preservam o histórico do fornecedor.
            try (PreparedStatement stmtVerificar = conexao.prepareStatement(sqlVerificarVinculo)) {
                stmtVerificar.setInt(1, idFornecedor);
                try (ResultSet rs = stmtVerificar.executeQuery()) {
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(null,
                                "Este fornecedor não pode ser excluído porque possui compras "
                                        + "vinculadas.\nMesmo compras finalizadas ou canceladas "
                                        + "mantêm o histórico do fornecedor.",
                                "Exclusão não permitida", JOptionPane.WARNING_MESSAGE);
                        return false;
                    }
                }
            }

            try (PreparedStatement stmtExcluir = conexao.prepareStatement(sqlExcluir)) {
                stmtExcluir.setInt(1, idFornecedor);
                int linhasAfetadas = stmtExcluir.executeUpdate();

                if (linhasAfetadas != 1) {
                    JOptionPane.showMessageDialog(null,
                            "Nenhum fornecedor foi excluído. O registro selecionado pode não existir mais.",
                            "Atenção", JOptionPane.WARNING_MESSAGE);
                    return false;
                }
            }

            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao excluir fornecedor.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }


    public Fornecedor buscarPorId(int idFornecedor) {
        String sql = "SELECT id_fornecedor, razao_social, nome_fantasia, cnpj, telefone, email, "
                + "endereco, cidade, uf, cep, ativo FROM fornecedor WHERE id_fornecedor = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idFornecedor);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao carregar fornecedor.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return null;
    }

    public List<Fornecedor> listarTodos() {
        return pesquisar(null, null);
    }

    public List<Fornecedor> pesquisar(String filtro, String texto) {
        List<Fornecedor> fornecedores = new ArrayList<>();

        String coluna = "razao_social";
        if (filtro != null) {
            switch (filtro.toUpperCase()) {
                case "ID":
                    coluna = "CAST(id_fornecedor AS VARCHAR)";
                    break;
                case "FANTASIA":
                    coluna = "nome_fantasia";
                    break;
                case "CNPJ":
                    coluna = "cnpj";
                    break;
                default:
                    coluna = "razao_social";
            }
        }

        boolean temFiltro = texto != null && !texto.trim().isEmpty();

        String sql = "SELECT id_fornecedor, razao_social, nome_fantasia, cnpj, telefone, email, "
                + "endereco, cidade, uf, cep, ativo FROM fornecedor ";
        if (temFiltro) {
            sql += "WHERE UPPER(" + coluna + ") LIKE UPPER(?) ";
        }
        sql += "ORDER BY razao_social";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            if (temFiltro) {
                stmt.setString(1, "%" + texto.trim() + "%");
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    fornecedores.add(mapear(rs));
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao pesquisar fornecedores.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return fornecedores;
    }

    private void preencherParametros(PreparedStatement stmt, Fornecedor fornecedor) throws SQLException {
        stmt.setString(1, fornecedor.getRazaoSocial());
        stmt.setString(2, fornecedor.getNomeFantasia());
        stmt.setString(3, fornecedor.getCnpj());
        stmt.setString(4, fornecedor.getTelefone());
        stmt.setString(5, fornecedor.getEmail());
        stmt.setString(6, fornecedor.getEndereco());
        stmt.setString(7, fornecedor.getCidade());
        stmt.setString(8, fornecedor.getUf());
        stmt.setString(9, fornecedor.getCep());
        stmt.setBoolean(10, fornecedor.isAtivo());
    }

    private Fornecedor mapear(ResultSet rs) throws SQLException {
        Fornecedor fornecedor = new Fornecedor();
        fornecedor.setIdFornecedor(rs.getInt("id_fornecedor"));
        fornecedor.setRazaoSocial(rs.getString("razao_social"));
        fornecedor.setNomeFantasia(rs.getString("nome_fantasia"));
        fornecedor.setCnpj(rs.getString("cnpj"));
        fornecedor.setTelefone(rs.getString("telefone"));
        fornecedor.setEmail(rs.getString("email"));
        fornecedor.setEndereco(rs.getString("endereco"));
        fornecedor.setCidade(rs.getString("cidade"));
        fornecedor.setUf(rs.getString("uf"));
        fornecedor.setCep(rs.getString("cep"));
        fornecedor.setAtivo(rs.getBoolean("ativo"));
        return fornecedor;
    }
}