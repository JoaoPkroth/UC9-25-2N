package dao;

import conexao.Conexao;
import model.Produto;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ProdutoDAO {

    public boolean inserir(Produto produto) {
        String sql = "INSERT INTO produto (descricao, unidade, preco_custo, preco_venda, "
                + "estoque, estoque_minimo, ativo) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            preencherParametros(stmt, produto);
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    produto.setIdProduto(rs.getInt(1));
                }
            }
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao cadastrar produto.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean alterar(Produto produto) {
        String sql = "UPDATE produto SET descricao = ?, unidade = ?, preco_custo = ?, "
                + "preco_venda = ?, estoque = ?, estoque_minimo = ?, ativo = ? WHERE id_produto = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            preencherParametros(stmt, produto);
            stmt.setInt(8, produto.getIdProduto());
            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao alterar produto.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean excluir(int idProduto) {
        String sql = "DELETE FROM produto WHERE id_produto = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idProduto);
            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao excluir produto.\nVerifique se ele não possui compras/vendas "
                            + "vinculadas.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public List<Produto> listarTodos() {
        return pesquisar(null, null);
    }

    public List<Produto> listarEstoqueBaixo() {
        List<Produto> produtos = new ArrayList<>();
        String sql = "SELECT id_produto, descricao, unidade, preco_custo, preco_venda, "
                + "estoque, estoque_minimo, ativo FROM produto "
                + "WHERE estoque <= estoque_minimo ORDER BY descricao";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                produtos.add(mapear(rs));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao consultar estoque baixo.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return produtos;
    }

    public List<Produto> pesquisar(String filtro, String texto) {
        List<Produto> produtos = new ArrayList<>();

        String coluna = "descricao";
        if (filtro != null && "ID".equalsIgnoreCase(filtro)) {
            coluna = "CAST(id_produto AS VARCHAR)";
        }

        boolean temFiltro = texto != null && !texto.trim().isEmpty();

        String sql = "SELECT id_produto, descricao, unidade, preco_custo, preco_venda, "
                + "estoque, estoque_minimo, ativo FROM produto ";
        if (temFiltro) {
            sql += "WHERE UPPER(" + coluna + ") LIKE UPPER(?) ";
        }
        sql += "ORDER BY descricao";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            if (temFiltro) {
                stmt.setString(1, "%" + texto.trim() + "%");
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    produtos.add(mapear(rs));
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao pesquisar produtos.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return produtos;
    }

    public Produto buscarPorId(int idProduto) {
        String sql = "SELECT id_produto, descricao, unidade, preco_custo, preco_venda, "
                + "estoque, estoque_minimo, ativo FROM produto WHERE id_produto = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idProduto);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao buscar produto.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }

    private void preencherParametros(PreparedStatement stmt, Produto produto) throws SQLException {
        stmt.setString(1, produto.getDescricao());
        stmt.setString(2, produto.getUnidade());
        stmt.setBigDecimal(3, produto.getPrecoCusto());
        stmt.setBigDecimal(4, produto.getPrecoVenda());
        stmt.setBigDecimal(5, produto.getEstoque());
        stmt.setBigDecimal(6, produto.getEstoqueMinimo());
        stmt.setBoolean(7, produto.isAtivo());
    }

    private Produto mapear(ResultSet rs) throws SQLException {
        Produto produto = new Produto();
        produto.setIdProduto(rs.getInt("id_produto"));
        produto.setDescricao(rs.getString("descricao"));
        produto.setUnidade(rs.getString("unidade"));
        produto.setPrecoCusto(rs.getBigDecimal("preco_custo"));
        produto.setPrecoVenda(rs.getBigDecimal("preco_venda"));
        produto.setEstoque(rs.getBigDecimal("estoque"));
        produto.setEstoqueMinimo(rs.getBigDecimal("estoque_minimo"));
        produto.setAtivo(rs.getBoolean("ativo"));
        return produto;
    }
}