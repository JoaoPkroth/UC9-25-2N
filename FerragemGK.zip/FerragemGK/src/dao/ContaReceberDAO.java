package dao;

import conexao.Conexao;
import model.ContaReceber;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ContaReceberDAO {

    public void inserir(Connection conexao, ContaReceber conta) throws SQLException {
        String sql = "INSERT INTO contas_receber (id_venda, numero_parcela, data_emissao, data_vencimento, "
                + "valor_parcela, status) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, conta.getIdVenda());
            stmt.setInt(2, conta.getNumeroParcela());
            stmt.setDate(3, Date.valueOf(conta.getDataEmissao()));
            stmt.setDate(4, Date.valueOf(conta.getDataVencimento()));
            stmt.setBigDecimal(5, conta.getValorParcela());
            stmt.setString(6, conta.getStatus());
            stmt.executeUpdate();
        }
    }

    public List<ContaReceber> pesquisar(String filtro, String texto) {
        List<ContaReceber> contas = new ArrayList<>();

        String sql = "SELECT r.id_conta_receber, r.id_venda, c.nome, r.numero_parcela, r.data_emissao, "
                + "r.data_vencimento, r.valor_parcela, r.valor_pago, r.data_recebimento, r.status "
                + "FROM contas_receber r "
                + "JOIN venda v ON v.id_venda = r.id_venda "
                + "JOIN cliente c ON c.id_cliente = v.id_cliente ";

        String filtroUpper = filtro == null ? "TODAS" : filtro.toUpperCase();
        boolean temTexto = texto != null && !texto.trim().isEmpty();

        switch (filtroUpper) {
            case "ABERTAS":
                sql += "WHERE r.status = 'ABERTA' ";
                break;
            case "RECEBIDAS":
                sql += "WHERE r.status = 'RECEBIDA' ";
                break;
            case "VENCIDAS":
                sql += "WHERE r.status = 'ABERTA' AND r.data_vencimento < CURRENT_DATE ";
                break;
            case "CLIENTE":
                sql += temTexto ? "WHERE UPPER(c.nome) LIKE UPPER(?) " : "";
                break;
            default:
                // TODAS - sem filtro
                break;
        }

        sql += "ORDER BY r.data_vencimento";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            if ("CLIENTE".equals(filtroUpper) && temTexto) {
                stmt.setString(1, "%" + texto.trim() + "%");
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    contas.add(mapear(rs));
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao pesquisar contas a receber.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return contas;
    }

    public void cancelarPorVenda(Connection conexao, int idVenda) throws SQLException {
        String sql = "UPDATE contas_receber SET status = 'CANCELADA' "
                + "WHERE id_venda = ? AND status = 'ABERTA'";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, idVenda);
            stmt.executeUpdate();
        }
    }

    public boolean darBaixa(int idContaReceber, LocalDate dataRecebimento, BigDecimal valorRecebido) {
        String sql = "UPDATE contas_receber SET status = 'RECEBIDA', data_recebimento = ?, valor_pago = ? "
                + "WHERE id_conta_receber = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setDate(1, Date.valueOf(dataRecebimento));
            stmt.setBigDecimal(2, valorRecebido);
            stmt.setInt(3, idContaReceber);
            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao dar baixa na conta a receber.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private ContaReceber mapear(ResultSet rs) throws SQLException {
        ContaReceber conta = new ContaReceber();
        conta.setIdContaReceber(rs.getInt("id_conta_receber"));
        conta.setIdVenda(rs.getInt("id_venda"));
        conta.setNomeCliente(rs.getString("nome"));
        conta.setNumeroParcela(rs.getInt("numero_parcela"));
        conta.setDataEmissao(rs.getDate("data_emissao").toLocalDate());
        conta.setDataVencimento(rs.getDate("data_vencimento").toLocalDate());
        conta.setValorParcela(rs.getBigDecimal("valor_parcela"));
        conta.setValorPago(rs.getBigDecimal("valor_pago"));
        conta.setDataRecebimento(rs.getDate("data_recebimento") != null
                ? rs.getDate("data_recebimento").toLocalDate() : null);
        conta.setStatus(rs.getString("status"));
        return conta;
    }
}