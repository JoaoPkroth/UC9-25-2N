package dao;

import conexao.Conexao;
import model.ContaPagar;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ContaPagarDAO {

    public void inserir(Connection conexao, ContaPagar conta) throws SQLException {
        String sql = "INSERT INTO contas_pagar (id_compra, numero_parcela, data_emissao, data_vencimento, "
                + "valor_parcela, status) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, conta.getIdCompra());
            stmt.setInt(2, conta.getNumeroParcela());
            stmt.setDate(3, Date.valueOf(conta.getDataEmissao()));
            stmt.setDate(4, Date.valueOf(conta.getDataVencimento()));
            stmt.setBigDecimal(5, conta.getValorParcela());
            stmt.setString(6, conta.getStatus());
            stmt.executeUpdate();
        }
    }

    public List<ContaPagar> pesquisar(String filtro, String texto) {
        List<ContaPagar> contas = new ArrayList<>();

        String sql = "SELECT p.id_conta_pagar, p.id_compra, f.nome_fantasia, f.razao_social, "
                + "p.numero_parcela, p.data_emissao, p.data_vencimento, p.valor_parcela, p.valor_pago, "
                + "p.data_pagamento, p.status "
                + "FROM contas_pagar p "
                + "JOIN compra c ON c.id_compra = p.id_compra "
                + "JOIN fornecedor f ON f.id_fornecedor = c.id_fornecedor ";

        String filtroUpper = filtro == null ? "TODAS" : filtro.toUpperCase();
        boolean temTexto = texto != null && !texto.trim().isEmpty();

        switch (filtroUpper) {
            case "ABERTAS":
                sql += "WHERE p.status = 'ABERTA' ";
                break;
            case "PAGAS":
                sql += "WHERE p.status = 'PAGA' ";
                break;
            case "VENCIDAS":
                sql += "WHERE p.status = 'ABERTA' AND p.data_vencimento < CURRENT_DATE ";
                break;
            case "FORNECEDOR":
                sql += temTexto ? "WHERE UPPER(f.razao_social) LIKE UPPER(?) OR UPPER(f.nome_fantasia) LIKE UPPER(?) " : "";
                break;
            default:
                // TODAS - sem filtro
                break;
        }

        sql += "ORDER BY p.data_vencimento";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            if ("FORNECEDOR".equals(filtroUpper) && temTexto) {
                stmt.setString(1, "%" + texto.trim() + "%");
                stmt.setString(2, "%" + texto.trim() + "%");
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    contas.add(mapear(rs));
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao pesquisar contas a pagar.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return contas;
    }

    public void cancelarPorCompra(Connection conexao, int idCompra) throws SQLException {
        String sql = "UPDATE contas_pagar SET status = 'CANCELADA' "
                + "WHERE id_compra = ? AND status = 'ABERTA'";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, idCompra);
            stmt.executeUpdate();
        }
    }

    public boolean darBaixa(int idContaPagar, java.time.LocalDate dataPagamento, java.math.BigDecimal valorPago) {
        String sql = "UPDATE contas_pagar SET status = 'PAGA', data_pagamento = ?, valor_pago = ? "
                + "WHERE id_conta_pagar = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setDate(1, Date.valueOf(dataPagamento));
            stmt.setBigDecimal(2, valorPago);
            stmt.setInt(3, idContaPagar);
            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao dar baixa na conta a pagar.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private ContaPagar mapear(ResultSet rs) throws SQLException {
        ContaPagar conta = new ContaPagar();
        conta.setIdContaPagar(rs.getInt("id_conta_pagar"));
        conta.setIdCompra(rs.getInt("id_compra"));
        String fantasia = rs.getString("nome_fantasia");
        conta.setNomeFornecedor(fantasia != null && !fantasia.isEmpty() ? fantasia : rs.getString("razao_social"));
        conta.setNumeroParcela(rs.getInt("numero_parcela"));
        conta.setDataEmissao(rs.getDate("data_emissao").toLocalDate());
        conta.setDataVencimento(rs.getDate("data_vencimento").toLocalDate());
        conta.setValorParcela(rs.getBigDecimal("valor_parcela"));
        conta.setValorPago(rs.getBigDecimal("valor_pago"));
        conta.setDataPagamento(rs.getDate("data_pagamento") != null ? rs.getDate("data_pagamento").toLocalDate() : null);
        conta.setStatus(rs.getString("status"));
        return conta;
    }
}