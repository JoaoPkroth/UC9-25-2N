package dao;

import conexao.Conexao;
import model.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ClienteDAO {

    public boolean inserir(Cliente cliente) {
        String sql = "INSERT INTO cliente (nome, cpf, telefone, email, endereco, cidade, uf, cep, ativo) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            preencherParametros(stmt, cliente);
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    cliente.setIdCliente(rs.getInt(1));
                }
            }
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao cadastrar cliente.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean alterar(Cliente cliente) {
        String sql = "UPDATE cliente SET nome = ?, cpf = ?, telefone = ?, email = ?, "
                + "endereco = ?, cidade = ?, uf = ?, cep = ?, ativo = ? WHERE id_cliente = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            preencherParametros(stmt, cliente);
            stmt.setInt(10, cliente.getIdCliente());
            int linhasAfetadas = stmt.executeUpdate();

            if (linhasAfetadas != 1) {
                JOptionPane.showMessageDialog(null,
                        "Nenhum cliente foi alterado. O registro selecionado pode não existir mais.",
                        "Atenção", JOptionPane.WARNING_MESSAGE);
                return false;
            }
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao alterar cliente.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean excluir(int idCliente) {
        String sql = "DELETE FROM cliente WHERE id_cliente = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idCliente);
            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao excluir cliente.\nVerifique se ele não possui vendas "
                            + "vinculadas.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }


    public Cliente buscarPorId(int idCliente) {
        String sql = "SELECT id_cliente, nome, cpf, telefone, email, endereco, cidade, uf, cep, ativo "
                + "FROM cliente WHERE id_cliente = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idCliente);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao carregar cliente.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return null;
    }

    public List<Cliente> listarTodos() {
        return pesquisar(null, null);
    }

    public List<Cliente> pesquisar(String filtro, String texto) {
        List<Cliente> clientes = new ArrayList<>();

        String coluna = "nome";
        if (filtro != null) {
            switch (filtro.toUpperCase()) {
                case "ID":
                    coluna = "CAST(id_cliente AS VARCHAR)";
                    break;
                case "CPF":
                    coluna = "cpf";
                    break;
                case "EMAIL":
                    coluna = "email";
                    break;
                default:
                    coluna = "nome";
            }
        }

        boolean temFiltro = texto != null && !texto.trim().isEmpty();

        String sql = "SELECT id_cliente, nome, cpf, telefone, email, endereco, cidade, uf, cep, ativo "
                + "FROM cliente ";
        if (temFiltro) {
            sql += "WHERE UPPER(" + coluna + ") LIKE UPPER(?) ";
        }
        sql += "ORDER BY nome";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            if (temFiltro) {
                stmt.setString(1, "%" + texto.trim() + "%");
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    clientes.add(mapear(rs));
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao pesquisar clientes.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return clientes;
    }

    private void preencherParametros(PreparedStatement stmt, Cliente cliente) throws SQLException {
        stmt.setString(1, cliente.getNome());
        stmt.setString(2, cliente.getCpf());
        stmt.setString(3, cliente.getTelefone());
        stmt.setString(4, cliente.getEmail());
        stmt.setString(5, cliente.getEndereco());
        stmt.setString(6, cliente.getCidade());
        stmt.setString(7, cliente.getUf());
        stmt.setString(8, cliente.getCep());
        stmt.setBoolean(9, cliente.isAtivo());
    }

    private Cliente mapear(ResultSet rs) throws SQLException {
        Cliente cliente = new Cliente();
        cliente.setIdCliente(rs.getInt("id_cliente"));
        cliente.setNome(rs.getString("nome"));
        cliente.setCpf(rs.getString("cpf"));
        cliente.setTelefone(rs.getString("telefone"));
        cliente.setEmail(rs.getString("email"));
        cliente.setEndereco(rs.getString("endereco"));
        cliente.setCidade(rs.getString("cidade"));
        cliente.setUf(rs.getString("uf"));
        cliente.setCep(rs.getString("cep"));
        cliente.setAtivo(rs.getBoolean("ativo"));
        return cliente;
    }
}