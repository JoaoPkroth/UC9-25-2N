package util;

import java.math.BigDecimal;

public class Validacao {

    private Validacao() {
    }

    public static boolean isCpfValido(String cpf) {
        if (cpf == null) {
            return false;
        }
        String numeros = cpf.replaceAll("[^0-9]", "");

        if (numeros.length() != 11 || todosDigitosIguais(numeros)) {
            return false;
        }

        int primeiroDigito = calcularDigitoVerificador(numeros.substring(0, 9), 10);
        int segundoDigito = calcularDigitoVerificador(numeros.substring(0, 9) + primeiroDigito, 11);

        return numeros.equals(numeros.substring(0, 9) + primeiroDigito + segundoDigito);
    }

    public static boolean isCnpjValido(String cnpj) {
        if (cnpj == null) {
            return false;
        }
        String numeros = cnpj.replaceAll("[^0-9]", "");

        if (numeros.length() != 14 || todosDigitosIguais(numeros)) {
            return false;
        }

        int[] pesosPrimeiroDigito = {5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2};
        int[] pesosSegundoDigito = {6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2};

        int primeiroDigito = calcularDigitoVerificadorCnpj(numeros.substring(0, 12), pesosPrimeiroDigito);
        int segundoDigito = calcularDigitoVerificadorCnpj(numeros.substring(0, 12) + primeiroDigito, pesosSegundoDigito);

        return numeros.equals(numeros.substring(0, 12) + primeiroDigito + segundoDigito);
    }

    public static boolean isPositivo(BigDecimal valor) {
        return valor != null && valor.compareTo(BigDecimal.ZERO) > 0;
    }

    public static boolean isEmailValido(String email) {
        if (email == null || email.trim().isEmpty()) {
            return true; 
        }
        String texto = email.trim();
        int arroba = texto.indexOf('@');
        return arroba > 0 && texto.indexOf('.', arroba) > arroba && !texto.endsWith(".");
    }

    private static boolean todosDigitosIguais(String numeros) {
        for (int i = 1; i < numeros.length(); i++) {
            if (numeros.charAt(i) != numeros.charAt(0)) {
                return false;
            }
        }
        return true;
    }

    private static int calcularDigitoVerificador(String base, int pesoInicial) {
        int soma = 0;
        int peso = pesoInicial;
        for (char c : base.toCharArray()) {
            soma += (c - '0') * peso;
            peso--;
        }
        int resto = soma % 11;
        return resto < 2 ? 0 : 11 - resto;
    }

    private static int calcularDigitoVerificadorCnpj(String base, int[] pesos) {
        int soma = 0;
        for (int i = 0; i < base.length(); i++) {
            soma += (base.charAt(i) - '0') * pesos[i];
        }
        int resto = soma % 11;
        return resto < 2 ? 0 : 11 - resto;
    }
}