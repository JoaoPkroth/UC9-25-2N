package util;

import javax.swing.JOptionPane;

public class Permissao {

    private Permissao() {
    }

    public static boolean exigirMaster() {
        if (!SessaoUsuario.isMaster()) {
            JOptionPane.showMessageDialog(null,
                    "Você não possui permissão para realizar esta operação.",
                    "Acesso negado", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
    
    public static boolean exigirLogin() {
        if (!SessaoUsuario.isLogado()) {
            JOptionPane.showMessageDialog(null,
                    "Nenhum usuário conectado.",
                    "Sessão inválida", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
}