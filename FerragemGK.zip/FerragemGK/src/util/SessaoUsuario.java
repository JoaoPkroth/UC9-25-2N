package util;

import model.Usuario;

public class SessaoUsuario {

    private static Usuario usuarioLogado;

    private SessaoUsuario() {
        
    }

    public static void setUsuario(Usuario usuario) {
        usuarioLogado = usuario;
    }

    public static Usuario getUsuario() {
        return usuarioLogado;
    }

    public static boolean isMaster() {
        return usuarioLogado != null && usuarioLogado.isMaster();
    }

    public static boolean isLogado() {
        return usuarioLogado != null;
    }

    public static void logout() {
        usuarioLogado = null;
    }
}