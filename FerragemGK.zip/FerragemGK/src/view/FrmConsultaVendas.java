package view;

import dao.VendaDAO;
import model.ProdutoVenda;
import model.Venda;
import service.VendaService;
import util.Permissao;
import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrmConsultaVendas extends javax.swing.JInternalFrame {

    private final VendaDAO vendaDAO = new VendaDAO();
    private final VendaService vendaService = new VendaService();
    private final NumberFormat moeda = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
    private final DateTimeFormatter formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private DefaultTableModel modeloTabela;
    private List<Venda> vendasExibidas = new ArrayList<>();

    public FrmConsultaVendas() {
        initComponents();
        aplicarEstiloVisual();

        cbFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(
                new String[]{"TODAS", "FINALIZADAS", "CANCELADAS", "CLIENTE"}));

        montarTabela();
        pesquisar();
    }

    private void aplicarEstiloVisual() {
        java.awt.Color fundo = new java.awt.Color(245, 243, 255);
        java.awt.Color textoLabel = new java.awt.Color(49, 46, 129);
        java.awt.Color headerTabela = new java.awt.Color(67, 56, 202);
        java.awt.Color corPrimaria = new java.awt.Color(79, 70, 229);
        java.awt.Color corPerigo = new java.awt.Color(225, 29, 72);

        painelPrincipal.setBackground(fundo);
        painelFiltro.setBackground(fundo);
        painelAcoes.setBackground(fundo);

        for (javax.swing.JLabel lbl : new javax.swing.JLabel[]{jLabel1, jLabel2}) {
            lbl.setForeground(textoLabel);
            lbl.setFont(lbl.getFont().deriveFont(java.awt.Font.BOLD));
        }

        for (javax.swing.JButton btn : new javax.swing.JButton[]{
            btnLocalizar, btnListarTodas, btnVerItens}) {
            btn.setBackground(corPrimaria);
            btn.setForeground(java.awt.Color.WHITE);
            btn.setFont(btn.getFont().deriveFont(java.awt.Font.BOLD));
        }
        btnCancelar.setBackground(corPerigo);
        btnCancelar.setForeground(java.awt.Color.WHITE);
        btnCancelar.setFont(btnCancelar.getFont().deriveFont(java.awt.Font.BOLD));

        tabelaVendas.getTableHeader().setBackground(headerTabela);
        tabelaVendas.getTableHeader().setForeground(java.awt.Color.WHITE);
        tabelaVendas.setSelectionBackground(corPrimaria);
        tabelaVendas.setSelectionForeground(java.awt.Color.WHITE);
        tabelaVendas.setGridColor(new java.awt.Color(237, 233, 254));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnListarTodas;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JButton btnVerItens;
    private javax.swing.JComboBox cbFiltro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel painelAcoes;
    private javax.swing.JPanel painelFiltro;
    private javax.swing.JPanel painelPrincipal;
    private javax.swing.JScrollPane scrollVendas;
    private javax.swing.JTable tabelaVendas;
    private javax.swing.JTextField txtPesquisa;
    // End of variables declaration//GEN-END:variables

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        painelPrincipal = new javax.swing.JPanel();
        painelFiltro = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cbFiltro = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        txtPesquisa = new javax.swing.JTextField();
        btnLocalizar = new javax.swing.JButton();
        btnListarTodas = new javax.swing.JButton();
        scrollVendas = new javax.swing.JScrollPane();
        tabelaVendas = new javax.swing.JTable();
        painelAcoes = new javax.swing.JPanel();
        btnVerItens = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Consulta de Vendas");

        painelPrincipal.setLayout(new java.awt.BorderLayout());

        painelFiltro.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtros"));
        painelFiltro.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));

        jLabel1.setText("Filtro:");
        painelFiltro.add(jLabel1);

        cbFiltro.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "CLIENTE", "ID", "DATA" }));
        painelFiltro.add(cbFiltro);

        jLabel2.setText("Pesquisa:");
        painelFiltro.add(jLabel2);

        txtPesquisa.setColumns(15);
        painelFiltro.add(txtPesquisa);

        btnLocalizar.setText("Localizar");
        btnLocalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLocalizarActionPerformed(evt);
            }
        });
        painelFiltro.add(btnLocalizar);

        btnListarTodas.setText("Listar todas");
        btnListarTodas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarTodasActionPerformed(evt);
            }
        });
        painelFiltro.add(btnListarTodas);

        painelPrincipal.add(painelFiltro, java.awt.BorderLayout.SOUTH);

        tabelaVendas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Cliente", "Data", "Valor total", "Pagamento", "Parcelas", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        scrollVendas.setViewportView(tabelaVendas);

        painelPrincipal.add(scrollVendas, java.awt.BorderLayout.CENTER);

        painelAcoes.setBorder(javax.swing.BorderFactory.createTitledBorder("Ações"));
        painelAcoes.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnVerItens.setText("Ver itens");
        btnVerItens.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerItensActionPerformed(evt);
            }
        });
        painelAcoes.add(btnVerItens);

        btnCancelar.setText("Cancelar venda");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        painelAcoes.add(btnCancelar);

        painelPrincipal.add(painelAcoes, java.awt.BorderLayout.NORTH);

        getContentPane().add(painelPrincipal, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 944, 530);
    }// </editor-fold>//GEN-END:initComponents

    private void btnLocalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLocalizarActionPerformed
        pesquisar();
    }//GEN-LAST:event_btnLocalizarActionPerformed

    private void btnListarTodasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarTodasActionPerformed
        listarTodas();
    }//GEN-LAST:event_btnListarTodasActionPerformed

    private void btnVerItensActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerItensActionPerformed
        verItens();
    }//GEN-LAST:event_btnVerItensActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        cancelarSelecionada();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void montarTabela() {
        String[] colunas = {"Código", "Cliente", "Data", "Forma de pagamento", "Parcelas", "Valor total", "Situação"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabelaVendas.setModel(modeloTabela);
    }

    private void listarTodas() {
        cbFiltro.setSelectedItem("TODAS");
        txtPesquisa.setText("");
        pesquisar();
    }

    private void pesquisar() {
        String filtro = (String) cbFiltro.getSelectedItem();
        String texto = txtPesquisa.getText();
        vendasExibidas = vendaDAO.pesquisar(filtro, texto);
        preencherTabela();
    }

    private void preencherTabela() {
        modeloTabela.setRowCount(0);
        for (Venda venda : vendasExibidas) {
            modeloTabela.addRow(new Object[]{
                venda.getIdVenda(), venda.getNomeCliente(),
                venda.getDataVenda().format(formatoData), venda.getFormaPagamento(),
                venda.getQuantidadeParcelas(), moeda.format(venda.getValorTotal()), venda.getStatus()
            });
        }
    }

    private Venda vendaSelecionada() {
        int linha = tabelaVendas.getSelectedRow();
        if (linha < 0 || linha >= vendasExibidas.size()) {
            return null;
        }
        return vendasExibidas.get(linha);
    }

    private void verItens() {
        Venda venda = vendaSelecionada();
        if (venda == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma venda na lista.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        List<ProdutoVenda> itens = vendaDAO.listarItens(venda.getIdVenda());
        if (itens.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Esta venda não possui itens cadastrados.",
                    "Itens da venda", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder texto = new StringBuilder();
        texto.append("Itens da venda nº ").append(venda.getIdVenda()).append(":\n\n");
        for (ProdutoVenda item : itens) {
            texto.append(String.format("%-30s qtd: %-8s vlr un.: %-12s subtotal: %s%n",
                    item.getDescricaoProduto(), item.getQuantidade(),
                    moeda.format(item.getValorUnitario()), moeda.format(item.getSubtotal())));
        }

        JOptionPane.showMessageDialog(this, texto.toString(), "Itens da venda", JOptionPane.INFORMATION_MESSAGE);
    }

    private void cancelarSelecionada() {
        if (!Permissao.exigirMaster()) {
            return;
        }

        Venda venda = vendaSelecionada();
        if (venda == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma venda na lista antes de cancelar.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!"FINALIZADA".equals(venda.getStatus())) {
            JOptionPane.showMessageDialog(this, "Apenas vendas finalizadas podem ser canceladas.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int resposta = JOptionPane.showConfirmDialog(this,
                "Cancelar a venda nº " + venda.getIdVenda() + "?\n"
                        + "O estoque será devolvido e as parcelas em aberto serão canceladas.",
                "Confirmação", JOptionPane.YES_NO_OPTION);

        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }

        boolean ok = vendaService.cancelarVenda(venda.getIdVenda());
        if (ok) {
            JOptionPane.showMessageDialog(this, "Venda cancelada com sucesso.");
            pesquisar();
        }
    }
}