package view;

import dao.ContaPagarDAO;
import model.ContaPagar;
import util.Permissao;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrmContasPagar extends javax.swing.JInternalFrame {

    private final ContaPagarDAO contaPagarDAO = new ContaPagarDAO();
    private final NumberFormat moeda = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
    private final DateTimeFormatter formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private DefaultTableModel modeloTabela;
    private List<ContaPagar> contasExibidas = new ArrayList<>();

    public FrmContasPagar() {
        initComponents();
        aplicarEstiloVisual();

        cbFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(
                new String[]{"TODAS", "ABERTAS", "PAGAS", "VENCIDAS", "FORNECEDOR"}));
        painelBaixa.setBorder(javax.swing.BorderFactory.createTitledBorder("Dar baixa na parcela selecionada"));

        montarTabela();
        tabelaContas.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabelaContas.getSelectedRow() >= 0) {
                carregarSelecionadaNoPainelBaixa();
            }
        });

        pesquisar();
    }

    private void aplicarEstiloVisual() {
        java.awt.Color fundo = new java.awt.Color(245, 243, 255);
        java.awt.Color textoLabel = new java.awt.Color(49, 46, 129);
        java.awt.Color headerTabela = new java.awt.Color(67, 56, 202);
        java.awt.Color corPrimaria = new java.awt.Color(79, 70, 229);
        java.awt.Color corSucesso = new java.awt.Color(5, 150, 105);

        painelPrincipal.setBackground(fundo);
        painelFiltro.setBackground(fundo);
        painelBaixa.setBackground(fundo);

        for (javax.swing.JLabel lbl : new javax.swing.JLabel[]{
            jLabel1, jLabel2, jLabel3, jLabel4}) {
            lbl.setForeground(textoLabel);
            lbl.setFont(lbl.getFont().deriveFont(java.awt.Font.BOLD));
        }

        for (javax.swing.JButton btn : new javax.swing.JButton[]{
            btnLocalizar, btnListarTodas}) {
            btn.setBackground(corPrimaria);
            btn.setForeground(java.awt.Color.WHITE);
            btn.setFont(btn.getFont().deriveFont(java.awt.Font.BOLD));
        }
        btnDarBaixa.setBackground(corSucesso);
        btnDarBaixa.setForeground(java.awt.Color.WHITE);
        btnDarBaixa.setFont(btnDarBaixa.getFont().deriveFont(java.awt.Font.BOLD));

        tabelaContas.getTableHeader().setBackground(headerTabela);
        tabelaContas.getTableHeader().setForeground(java.awt.Color.WHITE);
        tabelaContas.setSelectionBackground(corPrimaria);
        tabelaContas.setSelectionForeground(java.awt.Color.WHITE);
        tabelaContas.setGridColor(new java.awt.Color(237, 233, 254));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDarBaixa;
    private javax.swing.JButton btnListarTodas;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JComboBox cbFiltro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel painelBaixa;
    private javax.swing.JPanel painelFiltro;
    private javax.swing.JPanel painelPrincipal;
    private javax.swing.JScrollPane scrollContas;
    private javax.swing.JTable tabelaContas;
    private javax.swing.JTextField txtDataPagamento;
    private javax.swing.JTextField txtPesquisa;
    private javax.swing.JTextField txtValorPago;
    // End of variables declaration//GEN-END:variables

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        painelPrincipal = new javax.swing.JPanel();
        painelFiltro = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cbFiltro = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        txtPesquisa = new javax.swing.JTextField();
        btnLocalizar = new javax.swing.JButton();
        btnListarTodas = new javax.swing.JButton();
        scrollContas = new javax.swing.JScrollPane();
        tabelaContas = new javax.swing.JTable();
        painelBaixa = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtDataPagamento = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtValorPago = new javax.swing.JTextField();
        btnDarBaixa = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Contas a Pagar");

        painelPrincipal.setLayout(new java.awt.BorderLayout());

        painelFiltro.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtros"));
        painelFiltro.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));

        jLabel1.setText("Filtro:");
        painelFiltro.add(jLabel1);

        cbFiltro.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "FORNECEDOR", "ID", "VENCIMENTO", "STATUS" }));
        painelFiltro.add(cbFiltro);

        jLabel2.setText("Pesquisa:");
        painelFiltro.add(jLabel2);

        txtPesquisa.setColumns(15);
        painelFiltro.add(txtPesquisa);

        btnLocalizar.setText("Localizar");
        btnLocalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLocalizarActionPerformed(evt);
            }
        });
        painelFiltro.add(btnLocalizar);

        btnListarTodas.setText("Listar todas");
        btnListarTodas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarTodasActionPerformed(evt);
            }
        });
        painelFiltro.add(btnListarTodas);

        painelPrincipal.add(painelFiltro, java.awt.BorderLayout.SOUTH);

        tabelaContas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Fornecedor", "Emissão", "Vencimento", "Valor", "Valor pago", "Pagamento", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        scrollContas.setViewportView(tabelaContas);

        painelPrincipal.add(scrollContas, java.awt.BorderLayout.CENTER);

        painelBaixa.setBorder(javax.swing.BorderFactory.createTitledBorder("Baixa da conta"));
        painelBaixa.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        jLabel3.setText("Data do pagamento:");
        painelBaixa.add(jLabel3);

        txtDataPagamento.setColumns(10);
        painelBaixa.add(txtDataPagamento);

        jLabel4.setText("Valor pago:");
        painelBaixa.add(jLabel4);

        txtValorPago.setColumns(10);
        painelBaixa.add(txtValorPago);

        btnDarBaixa.setText("Dar baixa");
        btnDarBaixa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDarBaixaActionPerformed(evt);
            }
        });
        painelBaixa.add(btnDarBaixa);

        painelPrincipal.add(painelBaixa, java.awt.BorderLayout.NORTH);

        getContentPane().add(painelPrincipal, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 913, 539);
    }// </editor-fold>//GEN-END:initComponents

    private void btnLocalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLocalizarActionPerformed
        pesquisar();
    }//GEN-LAST:event_btnLocalizarActionPerformed

    private void btnListarTodasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarTodasActionPerformed
        listarTodas();
    }//GEN-LAST:event_btnListarTodasActionPerformed

    private void btnDarBaixaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDarBaixaActionPerformed
        darBaixaSelecionada();
    }//GEN-LAST:event_btnDarBaixaActionPerformed

    private void montarTabela() {
        String[] colunas = {"Código", "Compra", "Fornecedor", "Parcela", "Vencimento", "Valor", "Situação"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabelaContas.setModel(modeloTabela);
    }

    private void listarTodas() {
        cbFiltro.setSelectedItem("TODAS");
        txtPesquisa.setText("");
        pesquisar();
    }

    private void pesquisar() {
        String filtro = (String) cbFiltro.getSelectedItem();
        String texto = txtPesquisa.getText();
        contasExibidas = contaPagarDAO.pesquisar(filtro, texto);
        preencherTabela();
    }

    private void preencherTabela() {
        modeloTabela.setRowCount(0);
        for (ContaPagar conta : contasExibidas) {
            modeloTabela.addRow(new Object[]{
                conta.getIdContaPagar(), conta.getIdCompra(), conta.getNomeFornecedor(),
                conta.getNumeroParcela(), conta.getDataVencimento().format(formatoData),
                moeda.format(conta.getValorParcela()), conta.getStatus()
            });
        }
    }

    private void carregarSelecionadaNoPainelBaixa() {
        ContaPagar conta = contaSelecionada();
        if (conta == null) {
            return;
        }
        txtDataPagamento.setText(LocalDate.now().format(formatoData));
        txtValorPago.setText(conta.getValorParcela().toString());
    }

    private ContaPagar contaSelecionada() {
        int linha = tabelaContas.getSelectedRow();
        if (linha < 0 || linha >= contasExibidas.size()) {
            return null;
        }
        return contasExibidas.get(linha);
    }

    private void darBaixaSelecionada() {
        if (!Permissao.exigirMaster()) {
            return;
        }

        ContaPagar conta = contaSelecionada();
        if (conta == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma parcela na lista antes de dar baixa.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!"ABERTA".equals(conta.getStatus())) {
            JOptionPane.showMessageDialog(this, "Esta parcela já não está mais em aberto.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        LocalDate dataPagamento;
        try {
            dataPagamento = LocalDate.parse(txtDataPagamento.getText().trim(), formatoData);
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this, "Informe a data do pagamento no formato dd/MM/aaaa.",
                    "Data inválida", JOptionPane.WARNING_MESSAGE);
            return;
        }

        BigDecimal valorPago;
        try {
            valorPago = new BigDecimal(txtValorPago.getText().trim().replace(",", "."));
            if (valorPago.compareTo(BigDecimal.ZERO) <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Informe um valor pago válido e maior que zero.",
                    "Valor inválido", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int resposta = JOptionPane.showConfirmDialog(this,
                "Confirmar a baixa da parcela " + conta.getNumeroParcela()
                        + " da compra nº " + conta.getIdCompra() + "?",
                "Confirmação", JOptionPane.YES_NO_OPTION);

        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }

        boolean ok = contaPagarDAO.darBaixa(conta.getIdContaPagar(), dataPagamento, valorPago);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Baixa registrada com sucesso.");
            txtDataPagamento.setText("");
            txtValorPago.setText("");
            pesquisar();
        }
    }
}