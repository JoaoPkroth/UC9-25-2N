package view;

import dao.CompraDAO;
import model.Compra;
import model.ProdutoCompra;
import service.CompraService;
import util.Permissao;
import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrmConsultaCompras extends javax.swing.JInternalFrame {

    private final CompraDAO compraDAO = new CompraDAO();
    private final CompraService compraService = new CompraService();
    private final NumberFormat moeda = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
    private final DateTimeFormatter formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private DefaultTableModel modeloTabela;
    private List<Compra> comprasExibidas = new ArrayList<>();

    public FrmConsultaCompras() {
        initComponents();
        aplicarEstiloVisual();

        cbFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(
                new String[]{"TODAS", "FINALIZADAS", "CANCELADAS", "FORNECEDOR"}));

        montarTabela();
        pesquisar();
    }

    private void aplicarEstiloVisual() {
        java.awt.Color fundo = new java.awt.Color(245, 243, 255);
        java.awt.Color textoLabel = new java.awt.Color(49, 46, 129);
        java.awt.Color headerTabela = new java.awt.Color(67, 56, 202);
        java.awt.Color corPrimaria = new java.awt.Color(79, 70, 229);
        java.awt.Color corPerigo = new java.awt.Color(225, 29, 72);

        painelPrincipal.setBackground(fundo);
        painelFiltro.setBackground(fundo);
        painelAcoes.setBackground(fundo);

        for (javax.swing.JLabel lbl : new javax.swing.JLabel[]{jLabel1, jLabel2}) {
            lbl.setForeground(textoLabel);
            lbl.setFont(lbl.getFont().deriveFont(java.awt.Font.BOLD));
        }

        for (javax.swing.JButton btn : new javax.swing.JButton[]{
            btnLocalizar, btnListarTodas, btnVerItens}) {
            btn.setBackground(corPrimaria);
            btn.setForeground(java.awt.Color.WHITE);
            btn.setFont(btn.getFont().deriveFont(java.awt.Font.BOLD));
        }
        btnCancelar.setBackground(corPerigo);
        btnCancelar.setForeground(java.awt.Color.WHITE);
        btnCancelar.setFont(btnCancelar.getFont().deriveFont(java.awt.Font.BOLD));

        tabelaCompras.getTableHeader().setBackground(headerTabela);
        tabelaCompras.getTableHeader().setForeground(java.awt.Color.WHITE);
        tabelaCompras.setSelectionBackground(corPrimaria);
        tabelaCompras.setSelectionForeground(java.awt.Color.WHITE);
        tabelaCompras.setGridColor(new java.awt.Color(237, 233, 254));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnListarTodas;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JButton btnVerItens;
    private javax.swing.JComboBox cbFiltro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel painelAcoes;
    private javax.swing.JPanel painelFiltro;
    private javax.swing.JPanel painelPrincipal;
    private javax.swing.JScrollPane scrollCompras;
    private javax.swing.JTable tabelaCompras;
    private javax.swing.JTextField txtPesquisa;
    // End of variables declaration//GEN-END:variables

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        painelPrincipal = new javax.swing.JPanel();
        painelFiltro = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cbFiltro = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        txtPesquisa = new javax.swing.JTextField();
        btnLocalizar = new javax.swing.JButton();
        btnListarTodas = new javax.swing.JButton();
        scrollCompras = new javax.swing.JScrollPane();
        tabelaCompras = new javax.swing.JTable();
        painelAcoes = new javax.swing.JPanel();
        btnVerItens = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Consulta de Compras");

        painelPrincipal.setLayout(new java.awt.BorderLayout());

        painelFiltro.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtros"));
        painelFiltro.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));

        jLabel1.setText("Filtro:");
        painelFiltro.add(jLabel1);

        cbFiltro.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "FORNECEDOR", "ID", "DATA" }));
        painelFiltro.add(cbFiltro);

        jLabel2.setText("Pesquisa:");
        painelFiltro.add(jLabel2);

        txtPesquisa.setColumns(15);
        painelFiltro.add(txtPesquisa);

        btnLocalizar.setText("Localizar");
        btnLocalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLocalizarActionPerformed(evt);
            }
        });
        painelFiltro.add(btnLocalizar);

        btnListarTodas.setText("Listar todas");
        btnListarTodas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarTodasActionPerformed(evt);
            }
        });
        painelFiltro.add(btnListarTodas);

        painelPrincipal.add(painelFiltro, java.awt.BorderLayout.SOUTH);

        tabelaCompras.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Fornecedor", "Data", "Valor total", "Pagamento", "Parcelas", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        scrollCompras.setViewportView(tabelaCompras);

        painelPrincipal.add(scrollCompras, java.awt.BorderLayout.CENTER);

        painelAcoes.setBorder(javax.swing.BorderFactory.createTitledBorder("Ações"));
        painelAcoes.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnVerItens.setText("Ver itens");
        btnVerItens.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerItensActionPerformed(evt);
            }
        });
        painelAcoes.add(btnVerItens);

        btnCancelar.setText("Cancelar compra");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        painelAcoes.add(btnCancelar);

        painelPrincipal.add(painelAcoes, java.awt.BorderLayout.NORTH);

        getContentPane().add(painelPrincipal, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 1024, 529);
    }// </editor-fold>//GEN-END:initComponents

    private void btnLocalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLocalizarActionPerformed
        pesquisar();
    }//GEN-LAST:event_btnLocalizarActionPerformed

    private void btnListarTodasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarTodasActionPerformed
        listarTodas();
    }//GEN-LAST:event_btnListarTodasActionPerformed

    private void btnVerItensActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerItensActionPerformed
        verItens();
    }//GEN-LAST:event_btnVerItensActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        cancelarSelecionada();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void montarTabela() {
        String[] colunas = {"Código", "Fornecedor", "Data", "Forma de pagamento", "Parcelas", "Valor total", "Situação"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabelaCompras.setModel(modeloTabela);
    }

    private void listarTodas() {
        cbFiltro.setSelectedItem("TODAS");
        txtPesquisa.setText("");
        pesquisar();
    }

    private void pesquisar() {
        String filtro = (String) cbFiltro.getSelectedItem();
        String texto = txtPesquisa.getText();
        comprasExibidas = compraDAO.pesquisar(filtro, texto);
        preencherTabela();
    }

    private void preencherTabela() {
        modeloTabela.setRowCount(0);
        for (Compra compra : comprasExibidas) {
            modeloTabela.addRow(new Object[]{
                compra.getIdCompra(), compra.getNomeFornecedor(),
                compra.getDataCompra().format(formatoData), compra.getFormaPagamento(),
                compra.getQuantidadeParcelas(), moeda.format(compra.getValorTotal()), compra.getStatus()
            });
        }
    }

    private Compra compraSelecionada() {
        int linha = tabelaCompras.getSelectedRow();
        if (linha < 0 || linha >= comprasExibidas.size()) {
            return null;
        }
        return comprasExibidas.get(linha);
    }

    private void verItens() {
        Compra compra = compraSelecionada();
        if (compra == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma compra na lista.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        List<ProdutoCompra> itens = compraDAO.listarItens(compra.getIdCompra());
        if (itens.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Esta compra não possui itens cadastrados.",
                    "Itens da compra", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder texto = new StringBuilder();
        texto.append("Itens da compra nº ").append(compra.getIdCompra()).append(":\n\n");
        for (ProdutoCompra item : itens) {
            texto.append(String.format("%-30s qtd: %-8s vlr un.: %-12s subtotal: %s%n",
                    item.getDescricaoProduto(), item.getQuantidade(),
                    moeda.format(item.getValorUnitario()), moeda.format(item.getSubtotal())));
        }

        JOptionPane.showMessageDialog(this, texto.toString(), "Itens da compra", JOptionPane.INFORMATION_MESSAGE);
    }

    private void cancelarSelecionada() {
        if (!Permissao.exigirMaster()) {
            return;
        }

        Compra compra = compraSelecionada();
        if (compra == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma compra na lista antes de cancelar.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!"FINALIZADA".equals(compra.getStatus())) {
            JOptionPane.showMessageDialog(this, "Apenas compras finalizadas podem ser canceladas.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int resposta = JOptionPane.showConfirmDialog(this,
                "Cancelar a compra nº " + compra.getIdCompra() + "?\n"
                        + "O estoque será estornado e as parcelas em aberto serão canceladas.",
                "Confirmação", JOptionPane.YES_NO_OPTION);

        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }

        boolean ok = compraService.cancelarCompra(compra.getIdCompra());
        if (ok) {
            JOptionPane.showMessageDialog(this, "Compra cancelada com sucesso.");
            pesquisar();
        }
    }
}