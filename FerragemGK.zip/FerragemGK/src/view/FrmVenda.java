package view;

import dao.ClienteDAO;
import dao.ProdutoDAO;
import model.Cliente;
import model.Produto;
import model.ProdutoVenda;
import model.Venda;
import service.VendaService;
import util.SessaoUsuario;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

public class FrmVenda extends JInternalFrame {

    private final ClienteDAO clienteDAO = new ClienteDAO();
    private final ProdutoDAO produtoDAO = new ProdutoDAO();
    private final VendaService vendaService = new VendaService();

    private final NumberFormat moeda = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));

    private DefaultTableModel modeloItens;

    private final List<ProdutoVenda> itensVenda = new ArrayList<>();
    private BigDecimal valorTotal = BigDecimal.ZERO;

    public FrmVenda() {
        initComponents();
        aplicarEstiloVisual();
        modeloItens = (DefaultTableModel) tabelaItens.getModel();
        spnParcelas.setModel(new javax.swing.SpinnerNumberModel(1, 1, 36, 1));
        carregarCombos();
        atualizarEstadoParcelas();
    }

    private void aplicarEstiloVisual() {
        java.awt.Color fundo = new java.awt.Color(245, 243, 255);
        java.awt.Color textoLabel = new java.awt.Color(49, 46, 129);
        java.awt.Color headerTabela = new java.awt.Color(67, 56, 202);
        java.awt.Color corPrimaria = new java.awt.Color(79, 70, 229);
        java.awt.Color corPerigo = new java.awt.Color(225, 29, 72);
        java.awt.Color corDestaque = new java.awt.Color(124, 58, 237);

        painelTopo.setBackground(fundo);
        painelItens.setBackground(fundo);
        painelRodape.setBackground(fundo);
        painelBotoes.setBackground(fundo);

        for (javax.swing.JLabel lbl : new javax.swing.JLabel[]{
            lblCliente, lblProduto, lblQuantidade, lblEstoqueDisponivel,
            lblValorUnitario, lblFormaPagamento, lblParcelas, lblValorTotalTitulo}) {
            lbl.setForeground(textoLabel);
            lbl.setFont(lbl.getFont().deriveFont(java.awt.Font.BOLD));
        }
        lblValorTotal.setForeground(corDestaque);
        lblValorTotal.setFont(lblValorTotal.getFont().deriveFont(java.awt.Font.BOLD, 16f));

        btnAdicionar.setBackground(corPrimaria);
        btnAdicionar.setForeground(java.awt.Color.WHITE);
        btnAdicionar.setFont(btnAdicionar.getFont().deriveFont(java.awt.Font.BOLD));
        btnFinalizar.setBackground(corPrimaria);
        btnFinalizar.setForeground(java.awt.Color.WHITE);
        btnFinalizar.setFont(btnFinalizar.getFont().deriveFont(java.awt.Font.BOLD));
        btnRemover.setBackground(corPerigo);
        btnRemover.setForeground(java.awt.Color.WHITE);
        btnRemover.setFont(btnRemover.getFont().deriveFont(java.awt.Font.BOLD));

        tabelaItens.getTableHeader().setBackground(headerTabela);
        tabelaItens.getTableHeader().setForeground(java.awt.Color.WHITE);
        tabelaItens.setSelectionBackground(corPrimaria);
        tabelaItens.setSelectionForeground(java.awt.Color.WHITE);
        tabelaItens.setGridColor(new java.awt.Color(237, 233, 254));
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        painelTopo = new javax.swing.JPanel();
        lblCliente = new javax.swing.JLabel();
        cbCliente = new javax.swing.JComboBox();
        lblProduto = new javax.swing.JLabel();
        cbProduto = new javax.swing.JComboBox();
        lblEstoqueDisponivel = new javax.swing.JLabel();
        lblQuantidade = new javax.swing.JLabel();
        txtQuantidade = new javax.swing.JTextField();
        lblValorUnitario = new javax.swing.JLabel();
        txtValorUnitario = new javax.swing.JTextField();
        btnAdicionar = new javax.swing.JButton();
        painelItens = new javax.swing.JPanel();
        scrollPaneItens = new javax.swing.JScrollPane();
        tabelaItens = new javax.swing.JTable();
        painelBotoes = new javax.swing.JPanel();
        btnRemover = new javax.swing.JButton();
        painelRodape = new javax.swing.JPanel();
        lblValorTotalTitulo = new javax.swing.JLabel();
        lblValorTotal = new javax.swing.JLabel();
        lblFormaPagamento = new javax.swing.JLabel();
        cbFormaPagamento = new javax.swing.JComboBox();
        lblParcelas = new javax.swing.JLabel();
        spnParcelas = new javax.swing.JSpinner();
        btnFinalizar = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Venda de Mercadorias");
        setPreferredSize(new java.awt.Dimension(820, 600));

        painelTopo.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados da venda"));
        painelTopo.setLayout(new java.awt.GridBagLayout());

        lblCliente.setText("Cliente:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelTopo.add(lblCliente, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelTopo.add(cbCliente, gridBagConstraints);

        lblProduto.setText("Produto:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelTopo.add(lblProduto, gridBagConstraints);

        cbProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbProdutoActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelTopo.add(cbProduto, gridBagConstraints);

        lblEstoqueDisponivel.setText("Estoque: -");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelTopo.add(lblEstoqueDisponivel, gridBagConstraints);

        lblQuantidade.setText("Quantidade:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelTopo.add(lblQuantidade, gridBagConstraints);

        txtQuantidade.setColumns(10);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelTopo.add(txtQuantidade, gridBagConstraints);

        lblValorUnitario.setText("Valor unitário:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelTopo.add(lblValorUnitario, gridBagConstraints);

        txtValorUnitario.setColumns(12);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelTopo.add(txtValorUnitario, gridBagConstraints);

        btnAdicionar.setText("Adicionar produto");
        btnAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 8, 8);
        painelTopo.add(btnAdicionar, gridBagConstraints);

        getContentPane().add(painelTopo, java.awt.BorderLayout.NORTH);

        painelItens.setBorder(javax.swing.BorderFactory.createTitledBorder("Produtos da venda"));
        painelItens.setLayout(new java.awt.BorderLayout());

        tabelaItens.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Produto", "Quantidade", "Valor unitário", "Subtotal"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        scrollPaneItens.setViewportView(tabelaItens);

        painelItens.add(scrollPaneItens, java.awt.BorderLayout.CENTER);

        painelBotoes.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnRemover.setText("Remover item selecionado");
        btnRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverActionPerformed(evt);
            }
        });
        painelBotoes.add(btnRemover);

        painelItens.add(painelBotoes, java.awt.BorderLayout.SOUTH);

        getContentPane().add(painelItens, java.awt.BorderLayout.CENTER);

        painelRodape.setBorder(javax.swing.BorderFactory.createTitledBorder("Pagamento"));
        painelRodape.setLayout(new java.awt.GridBagLayout());

        lblValorTotalTitulo.setText("Valor total:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelRodape.add(lblValorTotalTitulo, gridBagConstraints);

        lblValorTotal.setText("R$ 0,00");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 18);
        painelRodape.add(lblValorTotal, gridBagConstraints);

        lblFormaPagamento.setText("Forma de pagamento:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelRodape.add(lblFormaPagamento, gridBagConstraints);

        cbFormaPagamento.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "A VISTA", "A PRAZO" }));
        cbFormaPagamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbFormaPagamentoActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.6;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelRodape.add(cbFormaPagamento, gridBagConstraints);

        lblParcelas.setText("Parcelas:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelRodape.add(lblParcelas, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.2;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        painelRodape.add(spnParcelas, gridBagConstraints);

        btnFinalizar.setText("Finalizar venda");
        btnFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFinalizarActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 6;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(8, 8, 8, 8);
        painelRodape.add(btnFinalizar, gridBagConstraints);

        getContentPane().add(painelRodape, java.awt.BorderLayout.SOUTH);

        setBounds(0, 0, 997, 549);
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdicionar;
    private javax.swing.JButton btnFinalizar;
    private javax.swing.JButton btnRemover;
    private javax.swing.JComboBox cbCliente;
    private javax.swing.JComboBox cbFormaPagamento;
    private javax.swing.JComboBox cbProduto;
    private javax.swing.JLabel lblCliente;
    private javax.swing.JLabel lblEstoqueDisponivel;
    private javax.swing.JLabel lblFormaPagamento;
    private javax.swing.JLabel lblParcelas;
    private javax.swing.JLabel lblProduto;
    private javax.swing.JLabel lblQuantidade;
    private javax.swing.JLabel lblValorTotal;
    private javax.swing.JLabel lblValorTotalTitulo;
    private javax.swing.JLabel lblValorUnitario;
    private javax.swing.JPanel painelBotoes;
    private javax.swing.JPanel painelItens;
    private javax.swing.JPanel painelRodape;
    private javax.swing.JPanel painelTopo;
    private javax.swing.JScrollPane scrollPaneItens;
    private javax.swing.JSpinner spnParcelas;
    private javax.swing.JTable tabelaItens;
    private javax.swing.JTextField txtQuantidade;
    private javax.swing.JTextField txtValorUnitario;
    // End of variables declaration//GEN-END:variables

    private void cbProdutoActionPerformed(java.awt.event.ActionEvent evt) {
        atualizarInformacoesProduto();
    }

    private void cbFormaPagamentoActionPerformed(java.awt.event.ActionEvent evt) {
        atualizarEstadoParcelas();
    }

    private void btnAdicionarActionPerformed(java.awt.event.ActionEvent evt) {
        adicionarProduto();
    }

    private void btnRemoverActionPerformed(java.awt.event.ActionEvent evt) {
        removerItemSelecionado();
    }

    private void btnFinalizarActionPerformed(java.awt.event.ActionEvent evt) {
        finalizarVenda();
    }

    private void atualizarInformacoesProduto() {
        Produto produto = (Produto) cbProduto.getSelectedItem();
        if (produto == null) {
            lblEstoqueDisponivel.setText("Estoque: -");
            return;
        }
        if (produto.getPrecoVenda() != null) {
            txtValorUnitario.setText(produto.getPrecoVenda().toString());
        }
        lblEstoqueDisponivel.setText("Estoque: " + formatarQuantidade(estoqueDisponivelParaProduto(produto)));
    }

    private String formatarQuantidade(BigDecimal valor) {
        if (valor == null) {
            return "0";
        }
        return valor.stripTrailingZeros().toPlainString();
    }

    private BigDecimal estoqueDisponivelParaProduto(Produto produto) {
        BigDecimal disponivel = produto.getEstoque() != null ? produto.getEstoque() : BigDecimal.ZERO;
        for (ProdutoVenda item : itensVenda) {
            if (item.getIdProduto() == produto.getIdProduto()) {
                disponivel = disponivel.subtract(item.getQuantidade());
            }
        }
        return disponivel;
    }

    private void adicionarProduto() {
        Produto produto = (Produto) cbProduto.getSelectedItem();
        if (produto == null) {
            JOptionPane.showMessageDialog(this, "Selecione um produto.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        BigDecimal quantidade = lerValorPositivo(txtQuantidade, "quantidade");
        if (quantidade == null) return;
        BigDecimal valorUnitario = lerValorPositivo(txtValorUnitario, "valor unitário");
        if (valorUnitario == null) return;
        BigDecimal disponivel = estoqueDisponivelParaProduto(produto);
        if (quantidade.compareTo(disponivel) > 0) {
            JOptionPane.showMessageDialog(this,
                    "Estoque insuficiente para \"" + produto.getDescricao() + "\".\n"
                    + "Disponível: " + formatarQuantidade(disponivel)
                    + " | Solicitado: " + formatarQuantidade(quantidade),
                    "Estoque insuficiente", JOptionPane.WARNING_MESSAGE);
            return;
        }
        ProdutoVenda item = new ProdutoVenda();
        item.setIdProduto(produto.getIdProduto());
        item.setDescricaoProduto(produto.getDescricao());
        item.setQuantidade(quantidade);
        item.setValorUnitario(valorUnitario);
        item.setSubtotal(quantidade.multiply(valorUnitario));
        itensVenda.add(item);
        modeloItens.addRow(new Object[]{
            item.getDescricaoProduto(), item.getQuantidade(),
            moeda.format(item.getValorUnitario()), moeda.format(item.getSubtotal())
        });
        recalcularValorTotal();
        atualizarInformacoesProduto();
        txtQuantidade.setText("");
        txtValorUnitario.setText("");
    }

    private void removerItemSelecionado() {
        int linha = tabelaItens.getSelectedRow();
        if (linha < 0) {
            JOptionPane.showMessageDialog(this, "Selecione um item da lista para remover.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        itensVenda.remove(linha);
        modeloItens.removeRow(linha);
        recalcularValorTotal();
        atualizarInformacoesProduto();
    }

    private void recalcularValorTotal() {
        valorTotal = BigDecimal.ZERO;
        for (ProdutoVenda item : itensVenda) {
            valorTotal = valorTotal.add(item.getSubtotal());
        }
        lblValorTotal.setText(moeda.format(valorTotal));
    }

    private BigDecimal lerValorPositivo(JTextField campo, String nomeCampo) {
        try {
            BigDecimal valor = new BigDecimal(campo.getText().trim().replace(",", "."));
            if (valor.compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(this, "Informe um(a) " + nomeCampo + " maior que zero.", "Valor inválido", JOptionPane.WARNING_MESSAGE);
                return null;
            }
            return valor;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Informe um(a) " + nomeCampo + " válido(a).", "Valor inválido", JOptionPane.WARNING_MESSAGE);
            return null;
        }
    }

    private void finalizarVenda() {
        Cliente cliente = (Cliente) cbCliente.getSelectedItem();
        if (cliente == null) {
            JOptionPane.showMessageDialog(this, "Selecione o cliente da venda.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (itensVenda.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Adicione ao menos um produto à venda.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Venda venda = new Venda();
        venda.setIdCliente(cliente.getIdCliente());
        venda.setIdUsuario(SessaoUsuario.getUsuario().getIdUsuario());
        venda.setDataVenda(LocalDate.now());
        venda.setFormaPagamento((String) cbFormaPagamento.getSelectedItem());
        venda.setQuantidadeParcelas((Integer) spnParcelas.getValue());
        venda.setValorTotal(valorTotal);
        venda.setItens(new ArrayList<>(itensVenda));
        boolean ok = vendaService.finalizarVenda(venda);
        if (ok) {
            JOptionPane.showMessageDialog(this,
                    "Venda nº " + venda.getIdVenda() + " finalizada com sucesso.\n"
                    + "Estoque atualizado e contas a receber geradas.");
            limparTela();
            carregarCombos();
        }
    }

    private void carregarCombos() {
        cbCliente.removeAllItems();
        List<Cliente> clientes = clienteDAO.listarTodos().stream()
                .filter(Cliente::isAtivo)
                .collect(Collectors.toList());
        for (Cliente cliente : clientes) {
            cbCliente.addItem(cliente);
        }

        cbProduto.removeAllItems();
        List<Produto> produtos = produtoDAO.listarTodos().stream()
                .filter(Produto::isAtivo)
                .collect(Collectors.toList());
        for (Produto produto : produtos) {
            cbProduto.addItem(produto);
        }
    }

    private void atualizarEstadoParcelas() {
        boolean aVista = "A VISTA".equals(cbFormaPagamento.getSelectedItem());
        if (aVista) {
            spnParcelas.setValue(1);
        }
        spnParcelas.setEnabled(!aVista);
    }

    private void limparTela() {
        itensVenda.clear();
        modeloItens.setRowCount(0);
        recalcularValorTotal();
        txtQuantidade.setText("");
        txtValorUnitario.setText("");
        cbFormaPagamento.setSelectedIndex(0);
        atualizarEstadoParcelas();
    }
}