package view;

import dao.ProdutoDAO;
import model.Produto;
import util.Permissao;
import java.math.BigDecimal;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrmProduto extends javax.swing.JInternalFrame {

    private final ProdutoDAO produtoDAO = new ProdutoDAO();
    private DefaultTableModel modeloTabela;

    public FrmProduto() {
        initComponents();
        aplicarEstiloVisual();
        configurarTabela();
        tabela.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabela.getSelectedRow() >= 0) {
                carregarSelecionado();
            }
        });
        listarTodos();
    }

    private void aplicarEstiloVisual() {
        java.awt.Color fundo = new java.awt.Color(245, 243, 255);
        java.awt.Color textoLabel = new java.awt.Color(49, 46, 129);
        java.awt.Color headerTabela = new java.awt.Color(67, 56, 202);
        java.awt.Color corPrimaria = new java.awt.Color(79, 70, 229);
        java.awt.Color corPerigo = new java.awt.Color(225, 29, 72);
        java.awt.Color corNeutra = new java.awt.Color(100, 116, 139);
        java.awt.Color corAlerta = new java.awt.Color(249, 115, 22);

        panelCadastro.setBackground(fundo);
        panelConsulta.setBackground(fundo);
        painelFiltro.setBackground(fundo);
        painelBotoes.setBackground(fundo);
        tabbedPane.setBackground(fundo);

        for (javax.swing.JLabel lbl : new javax.swing.JLabel[]{
            lblCodigo, lblDescricao, lblUnidade, lblPrecoCusto, lblPrecoVenda,
            lblEstoque, lblEstoqueMinimo, lblFiltro, lblPesquisa}) {
            lbl.setForeground(textoLabel);
            lbl.setFont(lbl.getFont().deriveFont(java.awt.Font.BOLD));
        }

        for (javax.swing.JButton btn : new javax.swing.JButton[]{
            btnNovo, btnSalvar, btnAlterar, btnLocalizar, btnListarTodos}) {
            btn.setBackground(corPrimaria);
            btn.setForeground(java.awt.Color.WHITE);
            btn.setFont(btn.getFont().deriveFont(java.awt.Font.BOLD));
        }
        btnExcluir.setBackground(corPerigo);
        btnExcluir.setForeground(java.awt.Color.WHITE);
        btnExcluir.setFont(btnExcluir.getFont().deriveFont(java.awt.Font.BOLD));
        btnCancelar.setBackground(corNeutra);
        btnCancelar.setForeground(java.awt.Color.WHITE);
        btnCancelar.setFont(btnCancelar.getFont().deriveFont(java.awt.Font.BOLD));
        btnEstoqueBaixo.setBackground(corAlerta);
        btnEstoqueBaixo.setForeground(java.awt.Color.WHITE);
        btnEstoqueBaixo.setFont(btnEstoqueBaixo.getFont().deriveFont(java.awt.Font.BOLD));

        tabela.getTableHeader().setBackground(headerTabela);
        tabela.getTableHeader().setForeground(java.awt.Color.WHITE);
        tabela.setSelectionBackground(corPrimaria);
        tabela.setSelectionForeground(java.awt.Color.WHITE);
        tabela.setGridColor(new java.awt.Color(237, 233, 254));
    }

    private void configurarTabela() {
        String[] colunas = {"Código", "Descrição", "Unid.", "Preço custo", "Preço venda", "Estoque", "Estoque mín.", "Ativo"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabela.setModel(modeloTabela);

        javax.swing.table.DefaultTableCellRenderer rendererQuantidade = new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            protected void setValue(Object value) {
                if (value instanceof BigDecimal) {
                    setText(formatarQuantidade((BigDecimal) value));
                } else {
                    super.setValue(value);
                }
            }
        };
        rendererQuantidade.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tabela.getColumnModel().getColumn(5).setCellRenderer(rendererQuantidade);
        tabela.getColumnModel().getColumn(6).setCellRenderer(rendererQuantidade);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        tabbedPane = new javax.swing.JTabbedPane();
        panelCadastro = new javax.swing.JPanel();
        lblCodigo = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        lblDescricao = new javax.swing.JLabel();
        txtDescricao = new javax.swing.JTextField();
        lblUnidade = new javax.swing.JLabel();
        txtUnidade = new javax.swing.JTextField();
        lblPrecoCusto = new javax.swing.JLabel();
        txtPrecoCusto = new javax.swing.JTextField();
        lblPrecoVenda = new javax.swing.JLabel();
        txtPrecoVenda = new javax.swing.JTextField();
        lblEstoque = new javax.swing.JLabel();
        txtEstoque = new javax.swing.JTextField();
        lblEstoqueMinimo = new javax.swing.JLabel();
        txtEstoqueMinimo = new javax.swing.JTextField();
        chkAtivo = new javax.swing.JCheckBox();
        painelBotoes = new javax.swing.JPanel();
        btnNovo = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        btnAlterar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        panelConsulta = new javax.swing.JPanel();
        painelFiltro = new javax.swing.JPanel();
        lblFiltro = new javax.swing.JLabel();
        cbFiltro = new javax.swing.JComboBox();
        lblPesquisa = new javax.swing.JLabel();
        txtPesquisa = new javax.swing.JTextField();
        btnLocalizar = new javax.swing.JButton();
        btnListarTodos = new javax.swing.JButton();
        btnEstoqueBaixo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Produtos");
        setPreferredSize(new java.awt.Dimension(760, 520));

        panelCadastro.setLayout(new java.awt.GridBagLayout());

        lblCodigo.setText("Código:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(lblCodigo, gridBagConstraints);

        txtId.setEditable(false);
        txtId.setColumns(8);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(txtId, gridBagConstraints);

        lblDescricao.setText("Descrição:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(lblDescricao, gridBagConstraints);

        txtDescricao.setColumns(30);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(txtDescricao, gridBagConstraints);

        lblUnidade.setText("Unidade (UN, KG, M...):");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(lblUnidade, gridBagConstraints);

        txtUnidade.setColumns(10);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(txtUnidade, gridBagConstraints);

        lblPrecoCusto.setText("Preço de custo:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(lblPrecoCusto, gridBagConstraints);

        txtPrecoCusto.setColumns(12);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(txtPrecoCusto, gridBagConstraints);

        lblPrecoVenda.setText("Preço de venda:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(lblPrecoVenda, gridBagConstraints);

        txtPrecoVenda.setColumns(12);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(txtPrecoVenda, gridBagConstraints);

        lblEstoque.setText("Estoque atual:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(lblEstoque, gridBagConstraints);

        txtEstoque.setColumns(12);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(txtEstoque, gridBagConstraints);

        lblEstoqueMinimo.setText("Estoque mínimo:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(lblEstoqueMinimo, gridBagConstraints);

        txtEstoqueMinimo.setColumns(12);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(txtEstoqueMinimo, gridBagConstraints);

        chkAtivo.setSelected(true);
        chkAtivo.setText("Ativo");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(chkAtivo, gridBagConstraints);

        painelBotoes.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnNovo.setText("Novo");
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoActionPerformed(evt);
            }
        });
        painelBotoes.add(btnNovo);

        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });
        painelBotoes.add(btnSalvar);

        btnAlterar.setText("Alterar");
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });
        painelBotoes.add(btnAlterar);

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });
        painelBotoes.add(btnExcluir);

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        painelBotoes.add(btnCancelar);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(painelBotoes, gridBagConstraints);

        tabbedPane.addTab("Cadastro", panelCadastro);

        panelConsulta.setLayout(new java.awt.BorderLayout());

        painelFiltro.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));

        lblFiltro.setText("Filtro:");
        painelFiltro.add(lblFiltro);

        cbFiltro.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "DESCRICAO", "ID" }));
        cbFiltro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbFiltroActionPerformed(evt);
            }
        });
        painelFiltro.add(cbFiltro);

        lblPesquisa.setText("Pesquisa:");
        painelFiltro.add(lblPesquisa);

        txtPesquisa.setColumns(15);
        painelFiltro.add(txtPesquisa);

        btnLocalizar.setText("Localizar");
        btnLocalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLocalizarActionPerformed(evt);
            }
        });
        painelFiltro.add(btnLocalizar);

        btnListarTodos.setText("Listar todos");
        btnListarTodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarTodosActionPerformed(evt);
            }
        });
        painelFiltro.add(btnListarTodos);

        btnEstoqueBaixo.setText("Estoque baixo");
        btnEstoqueBaixo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEstoqueBaixoActionPerformed(evt);
            }
        });
        painelFiltro.add(btnEstoqueBaixo);

        panelConsulta.add(painelFiltro, java.awt.BorderLayout.NORTH);

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Descrição", "Unid.", "Preço custo", "Preço venda", "Estoque", "Estoque mín.", "Ativo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabela);

        panelConsulta.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Consulta", panelConsulta);

        getContentPane().add(tabbedPane, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 1010, 442);
    }// </editor-fold>//GEN-END:initComponents

    private void cbFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbFiltroActionPerformed
    }//GEN-LAST:event_cbFiltroActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEstoqueBaixo;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnListarTodos;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JComboBox cbFiltro;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCodigo;
    private javax.swing.JLabel lblDescricao;
    private javax.swing.JLabel lblEstoque;
    private javax.swing.JLabel lblEstoqueMinimo;
    private javax.swing.JLabel lblFiltro;
    private javax.swing.JLabel lblPesquisa;
    private javax.swing.JLabel lblPrecoCusto;
    private javax.swing.JLabel lblPrecoVenda;
    private javax.swing.JLabel lblUnidade;
    private javax.swing.JPanel painelBotoes;
    private javax.swing.JPanel painelFiltro;
    private javax.swing.JPanel panelCadastro;
    private javax.swing.JPanel panelConsulta;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JTable tabela;
    private javax.swing.JTextField txtDescricao;
    private javax.swing.JTextField txtEstoque;
    private javax.swing.JTextField txtEstoqueMinimo;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtPesquisa;
    private javax.swing.JTextField txtPrecoCusto;
    private javax.swing.JTextField txtPrecoVenda;
    private javax.swing.JTextField txtUnidade;
    // End of variables declaration//GEN-END:variables

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {
        limparCampos();
    }

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {
        salvar();
    }

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {
        alterar();
    }

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {
        excluir();
    }

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {
        limparCampos();
    }

    private void btnLocalizarActionPerformed(java.awt.event.ActionEvent evt) {
        pesquisar();
    }

    private void btnListarTodosActionPerformed(java.awt.event.ActionEvent evt) {
        listarTodos();
    }

    private void btnEstoqueBaixoActionPerformed(java.awt.event.ActionEvent evt) {
        preencherTabela(produtoDAO.listarEstoqueBaixo());
    }

    private void salvar() {
        Produto produto = validarECriarProduto();
        if (produto == null) {
            return;
        }

        boolean ok = produtoDAO.inserir(produto);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Produto cadastrado com sucesso.");
            limparCampos();
            listarTodos();
        }
    }

    private void alterar() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Selecione um produto na aba Consulta antes de alterar.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Produto produto = validarECriarProduto();
        if (produto == null) {
            return;
        }
        produto.setIdProduto(Integer.parseInt(txtId.getText()));

        boolean ok = produtoDAO.alterar(produto);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Produto alterado com sucesso.");
            limparCampos();
            listarTodos();
        }
    }

    private void excluir() {
        if (!Permissao.exigirMaster()) {
            return;
        }
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Selecione um produto na aba Consulta antes de excluir.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int resposta = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir o produto \"" + txtDescricao.getText() + "\"?",
                "Confirmação", JOptionPane.YES_NO_OPTION);

        if (resposta == JOptionPane.YES_OPTION) {
            boolean ok = produtoDAO.excluir(Integer.parseInt(txtId.getText()));
            if (ok) {
                JOptionPane.showMessageDialog(this, "Produto excluído com sucesso.");
                limparCampos();
                listarTodos();
            }
        }
    }

    private void listarTodos() {
        preencherTabela(produtoDAO.listarTodos());
    }

    private void pesquisar() {
        String filtro = (String) cbFiltro.getSelectedItem();
        String texto = txtPesquisa.getText();
        preencherTabela(produtoDAO.pesquisar(filtro, texto));
    }

    private void preencherTabela(List<Produto> produtos) {
        modeloTabela.setRowCount(0);
        for (Produto p : produtos) {
            modeloTabela.addRow(new Object[]{
                p.getIdProduto(), p.getDescricao(), p.getUnidade(), p.getPrecoCusto(),
                p.getPrecoVenda(), p.getEstoque(), p.getEstoqueMinimo(), p.isAtivo() ? "Sim" : "Não"
            });
        }
    }

    private void carregarSelecionado() {
        int linha = tabela.getSelectedRow();
        txtId.setText(modeloTabela.getValueAt(linha, 0).toString());
        txtDescricao.setText(String.valueOf(modeloTabela.getValueAt(linha, 1)));
        txtUnidade.setText(String.valueOf(modeloTabela.getValueAt(linha, 2)));
        txtPrecoCusto.setText(String.valueOf(modeloTabela.getValueAt(linha, 3)));
        txtPrecoVenda.setText(String.valueOf(modeloTabela.getValueAt(linha, 4)));
        txtEstoque.setText(formatarQuantidade((BigDecimal) modeloTabela.getValueAt(linha, 5)));
        txtEstoqueMinimo.setText(formatarQuantidade((BigDecimal) modeloTabela.getValueAt(linha, 6)));
        chkAtivo.setSelected("Sim".equals(modeloTabela.getValueAt(linha, 7)));

        tabbedPane.setSelectedIndex(0);
    }

    private Produto validarECriarProduto() {
        if (txtDescricao.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe a descrição do produto.",
                    "Campo obrigatório", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        if (txtUnidade.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe a unidade do produto.",
                    "Campo obrigatório", JOptionPane.WARNING_MESSAGE);
            return null;
        }

        BigDecimal precoCusto = lerValorPositivo(txtPrecoCusto, "Preço de custo");
        if (precoCusto == null) {
            return null;
        }
        BigDecimal precoVenda = lerValorPositivo(txtPrecoVenda, "Preço de venda");
        if (precoVenda == null) {
            return null;
        }
        BigDecimal estoque = lerValorNaoNegativo(txtEstoque, "Estoque atual");
        if (estoque == null) {
            return null;
        }
        BigDecimal estoqueMinimo = lerValorNaoNegativo(txtEstoqueMinimo, "Estoque mínimo");
        if (estoqueMinimo == null) {
            return null;
        }

        Produto produto = new Produto();
        produto.setDescricao(txtDescricao.getText().trim());
        produto.setUnidade(txtUnidade.getText().trim().toUpperCase());
        produto.setPrecoCusto(precoCusto);
        produto.setPrecoVenda(precoVenda);
        produto.setEstoque(estoque);
        produto.setEstoqueMinimo(estoqueMinimo);
        produto.setAtivo(chkAtivo.isSelected());
        return produto;
    }

    private String formatarQuantidade(BigDecimal valor) {
        if (valor == null) {
            return "0";
        }
        return valor.stripTrailingZeros().toPlainString();
    }

    private BigDecimal lerValorPositivo(javax.swing.JTextField campo, String nomeCampo) {
        BigDecimal valor = lerValorNaoNegativo(campo, nomeCampo);
        if (valor != null && valor.compareTo(BigDecimal.ZERO) <= 0) {
            JOptionPane.showMessageDialog(this, nomeCampo + " deve ser maior que zero.",
                    "Valor inválido", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        return valor;
    }

    private BigDecimal lerValorNaoNegativo(javax.swing.JTextField campo, String nomeCampo) {
        String texto = campo.getText().trim().replace(",", ".");
        if (texto.isEmpty()) {
            texto = "0";
        }
        try {
            BigDecimal valor = new BigDecimal(texto);
            if (valor.compareTo(BigDecimal.ZERO) < 0) {
                JOptionPane.showMessageDialog(this, nomeCampo + " não pode ser negativo.",
                        "Valor inválido", JOptionPane.WARNING_MESSAGE);
                return null;
            }
            return valor;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, nomeCampo + " inválido. Use apenas números.",
                    "Valor inválido", JOptionPane.WARNING_MESSAGE);
            return null;
        }
    }

    private void limparCampos() {
        txtId.setText("");
        txtDescricao.setText("");
        txtUnidade.setText("");
        txtPrecoCusto.setText("");
        txtPrecoVenda.setText("");
        txtEstoque.setText("");
        txtEstoqueMinimo.setText("");
        chkAtivo.setSelected(true);
    }
}