package view;

import dao.ContaReceberDAO;
import model.ContaReceber;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrmContasReceber extends javax.swing.JInternalFrame {

    private final ContaReceberDAO contaReceberDAO = new ContaReceberDAO();
    private final NumberFormat moeda = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
    private final DateTimeFormatter formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private DefaultTableModel modeloTabela;
    private List<ContaReceber> contasExibidas = new ArrayList<>();

    public FrmContasReceber() {
        initComponents();
        aplicarEstiloVisual();
        setSize(760, 500);
        configurarTabela();
        configurarListeners();
        pesquisar();
    }

    private void aplicarEstiloVisual() {
        java.awt.Color fundo = new java.awt.Color(245, 243, 255);
        java.awt.Color textoLabel = new java.awt.Color(49, 46, 129);
        java.awt.Color headerTabela = new java.awt.Color(67, 56, 202);
        java.awt.Color corPrimaria = new java.awt.Color(79, 70, 229);
        java.awt.Color corSucesso = new java.awt.Color(5, 150, 105);

        painelPrincipal.setBackground(fundo);
        painelFiltro.setBackground(fundo);
        painelBaixa.setBackground(fundo);

        for (javax.swing.JLabel lbl : new javax.swing.JLabel[]{
            lblFiltro, lblPesquisa, lblDataRecebimento, lblValorRecebido}) {
            lbl.setForeground(textoLabel);
            lbl.setFont(lbl.getFont().deriveFont(java.awt.Font.BOLD));
        }

        btnLocalizar.setBackground(corPrimaria);
        btnLocalizar.setForeground(java.awt.Color.WHITE);
        btnLocalizar.setFont(btnLocalizar.getFont().deriveFont(java.awt.Font.BOLD));
        btnListarTodas.setBackground(corPrimaria);
        btnListarTodas.setForeground(java.awt.Color.WHITE);
        btnListarTodas.setFont(btnListarTodas.getFont().deriveFont(java.awt.Font.BOLD));
        btnReceber.setBackground(corSucesso);
        btnReceber.setForeground(java.awt.Color.WHITE);
        btnReceber.setFont(btnReceber.getFont().deriveFont(java.awt.Font.BOLD));

        tabela.getTableHeader().setBackground(headerTabela);
        tabela.getTableHeader().setForeground(java.awt.Color.WHITE);
        tabela.setSelectionBackground(corPrimaria);
        tabela.setSelectionForeground(java.awt.Color.WHITE);
        tabela.setGridColor(new java.awt.Color(237, 233, 254));
    }

    private void configurarTabela() {
        String[] colunas = {"Código", "Venda", "Cliente", "Parcela", "Vencimento", "Valor", "Situação"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabela.setModel(modeloTabela);
        tabela.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabela.getSelectedRow() >= 0) {
                carregarSelecionadaNoPainelBaixa();
            }
        });
    }

    private void configurarListeners() {
        btnLocalizar.addActionListener(e -> pesquisar());
        btnListarTodas.addActionListener(e -> {
            cbFiltro.setSelectedItem("TODAS");
            txtPesquisa.setText("");
            pesquisar();
        });
        btnReceber.addActionListener(e -> receberSelecionada());
    }

    private void pesquisar() {
        String filtro = (String) cbFiltro.getSelectedItem();
        String texto = txtPesquisa.getText();
        contasExibidas = contaReceberDAO.pesquisar(filtro, texto);
        preencherTabela();
    }

    private void preencherTabela() {
        modeloTabela.setRowCount(0);
        for (ContaReceber conta : contasExibidas) {
            modeloTabela.addRow(new Object[]{
                conta.getIdContaReceber(), conta.getIdVenda(), conta.getNomeCliente(),
                conta.getNumeroParcela(), conta.getDataVencimento().format(formatoData),
                moeda.format(conta.getValorParcela()), conta.getStatus()
            });
        }
    }

    private void carregarSelecionadaNoPainelBaixa() {
        ContaReceber conta = contaSelecionada();
        if (conta == null) {
            return;
        }
        txtDataRecebimento.setText(LocalDate.now().format(formatoData));
        txtValorRecebido.setText(conta.getValorParcela().toString());
    }

    private ContaReceber contaSelecionada() {
        int linha = tabela.getSelectedRow();
        if (linha < 0 || linha >= contasExibidas.size()) {
            return null;
        }
        return contasExibidas.get(linha);
    }

    private void receberSelecionada() {
        ContaReceber conta = contaSelecionada();
        if (conta == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma parcela na lista antes de receber.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!"ABERTA".equals(conta.getStatus())) {
            JOptionPane.showMessageDialog(this, "Esta parcela já não está mais em aberto.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        LocalDate dataRecebimento;
        try {
            dataRecebimento = LocalDate.parse(txtDataRecebimento.getText().trim(), formatoData);
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this, "Informe a data do recebimento no formato dd/MM/aaaa.",
                    "Data inválida", JOptionPane.WARNING_MESSAGE);
            return;
        }

        BigDecimal valorRecebido;
        try {
            valorRecebido = new BigDecimal(txtValorRecebido.getText().trim().replace(",", "."));
            if (valorRecebido.compareTo(BigDecimal.ZERO) <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Informe um valor recebido válido e maior que zero.",
                    "Valor inválido", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int resposta = JOptionPane.showConfirmDialog(this,
                "Confirmar o recebimento da parcela " + conta.getNumeroParcela()
                        + " da venda nº " + conta.getIdVenda() + "?",
                "Confirmação", JOptionPane.YES_NO_OPTION);

        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }

        boolean ok = contaReceberDAO.darBaixa(conta.getIdContaReceber(), dataRecebimento, valorRecebido);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Recebimento registrado com sucesso.");
            txtDataRecebimento.setText("");
            txtValorRecebido.setText("");
            pesquisar();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        painelPrincipal = new javax.swing.JPanel();
        painelFiltro = new javax.swing.JPanel();
        lblFiltro = new javax.swing.JLabel();
        cbFiltro = new javax.swing.JComboBox();
        lblPesquisa = new javax.swing.JLabel();
        txtPesquisa = new javax.swing.JTextField();
        btnLocalizar = new javax.swing.JButton();
        btnListarTodas = new javax.swing.JButton();
        scrollTabela = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        painelBaixa = new javax.swing.JPanel();
        lblDataRecebimento = new javax.swing.JLabel();
        txtDataRecebimento = new javax.swing.JTextField();
        lblValorRecebido = new javax.swing.JLabel();
        txtValorRecebido = new javax.swing.JTextField();
        btnReceber = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Contas a Receber");

        painelPrincipal.setLayout(new java.awt.BorderLayout());

        painelFiltro.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtros"));
        painelFiltro.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));

        lblFiltro.setText("Filtro:");
        painelFiltro.add(lblFiltro);

        cbFiltro.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "CLIENTE", "ID", "VENCIMENTO", "STATUS" }));
        painelFiltro.add(cbFiltro);

        lblPesquisa.setText("Pesquisa:");
        painelFiltro.add(lblPesquisa);

        txtPesquisa.setColumns(15);
        painelFiltro.add(txtPesquisa);

        btnLocalizar.setText("Localizar");
        painelFiltro.add(btnLocalizar);

        btnListarTodas.setText("Listar todas");
        painelFiltro.add(btnListarTodas);

        painelPrincipal.add(painelFiltro, java.awt.BorderLayout.SOUTH);

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Cliente", "Emissão", "Vencimento", "Valor", "Valor recebido", "Recebimento", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        scrollTabela.setViewportView(tabela);

        painelPrincipal.add(scrollTabela, java.awt.BorderLayout.CENTER);

        painelBaixa.setBorder(javax.swing.BorderFactory.createTitledBorder("Receber a parcela selecionada"));
        painelBaixa.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        lblDataRecebimento.setText("Data do recebimento:");
        painelBaixa.add(lblDataRecebimento);

        txtDataRecebimento.setColumns(10);
        painelBaixa.add(txtDataRecebimento);

        lblValorRecebido.setText("Valor recebido:");
        painelBaixa.add(lblValorRecebido);

        txtValorRecebido.setColumns(10);
        painelBaixa.add(txtValorRecebido);

        btnReceber.setText("Receber");
        painelBaixa.add(btnReceber);

        painelPrincipal.add(painelBaixa, java.awt.BorderLayout.NORTH);

        getContentPane().add(painelPrincipal, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 919, 532);
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnListarTodas;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JButton btnReceber;
    private javax.swing.JComboBox cbFiltro;
    private javax.swing.JLabel lblDataRecebimento;
    private javax.swing.JLabel lblFiltro;
    private javax.swing.JLabel lblPesquisa;
    private javax.swing.JLabel lblValorRecebido;
    private javax.swing.JPanel painelBaixa;
    private javax.swing.JPanel painelFiltro;
    private javax.swing.JPanel painelPrincipal;
    private javax.swing.JScrollPane scrollTabela;
    private javax.swing.JTable tabela;
    private javax.swing.JTextField txtDataRecebimento;
    private javax.swing.JTextField txtPesquisa;
    private javax.swing.JTextField txtValorRecebido;
    // End of variables declaration//GEN-END:variables
}