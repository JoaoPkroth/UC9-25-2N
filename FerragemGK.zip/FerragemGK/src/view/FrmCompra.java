package view;

import dao.FornecedorDAO;
import dao.ProdutoDAO;
import model.Compra;
import model.Fornecedor;
import model.Produto;
import model.ProdutoCompra;
import service.CompraService;
import util.SessaoUsuario;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrmCompra extends javax.swing.JInternalFrame {

    private final FornecedorDAO fornecedorDAO = new FornecedorDAO();
    private final ProdutoDAO produtoDAO = new ProdutoDAO();
    private final CompraService compraService = new CompraService();

    private final NumberFormat moeda = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));

    private DefaultTableModel modeloItens;
    private final List<ProdutoCompra> itensCompra = new ArrayList<>();
    private BigDecimal valorTotal = BigDecimal.ZERO;

    public FrmCompra() {
        initComponents();
        aplicarEstiloVisual();

        cbFormaPagamento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{"A VISTA", "A PRAZO"}));
        spnParcelas.setModel(new javax.swing.SpinnerNumberModel(1, 1, 36, 1));
        painelItens.setBorder(javax.swing.BorderFactory.createTitledBorder("Produtos da compra"));

        montarTabelaItens();
        lblValorTotal.setText(moeda.format(BigDecimal.ZERO));
        atualizarEstadoParcelas();
        carregarCombos();
    }

    private void aplicarEstiloVisual() {
        java.awt.Color fundo = new java.awt.Color(245, 243, 255);
        java.awt.Color textoLabel = new java.awt.Color(49, 46, 129);
        java.awt.Color headerTabela = new java.awt.Color(67, 56, 202);
        java.awt.Color corPrimaria = new java.awt.Color(79, 70, 229);
        java.awt.Color corPerigo = new java.awt.Color(225, 29, 72);
        java.awt.Color corDestaque = new java.awt.Color(124, 58, 237);

        painelPrincipal.setBackground(fundo);
        painelTopo.setBackground(fundo);
        painelItens.setBackground(fundo);
        painelRodape.setBackground(fundo);
        painelBotoesItens.setBackground(fundo);

        for (javax.swing.JLabel lbl : new javax.swing.JLabel[]{
            jLabel1, jLabel2, jLabel3, jLabel4, jLabel5, jLabel6, jLabel7}) {
            lbl.setForeground(textoLabel);
            lbl.setFont(lbl.getFont().deriveFont(java.awt.Font.BOLD));
        }
        lblValorTotal.setForeground(corDestaque);
        lblValorTotal.setFont(lblValorTotal.getFont().deriveFont(java.awt.Font.BOLD, 16f));

        btnAdicionar.setBackground(corPrimaria);
        btnAdicionar.setForeground(java.awt.Color.WHITE);
        btnAdicionar.setFont(btnAdicionar.getFont().deriveFont(java.awt.Font.BOLD));
        btnFinalizar.setBackground(corPrimaria);
        btnFinalizar.setForeground(java.awt.Color.WHITE);
        btnFinalizar.setFont(btnFinalizar.getFont().deriveFont(java.awt.Font.BOLD));
        btnRemover.setBackground(corPerigo);
        btnRemover.setForeground(java.awt.Color.WHITE);
        btnRemover.setFont(btnRemover.getFont().deriveFont(java.awt.Font.BOLD));

        tabelaItens.getTableHeader().setBackground(headerTabela);
        tabelaItens.getTableHeader().setForeground(java.awt.Color.WHITE);
        tabelaItens.setSelectionBackground(corPrimaria);
        tabelaItens.setSelectionForeground(java.awt.Color.WHITE);
        tabelaItens.setGridColor(new java.awt.Color(237, 233, 254));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdicionar;
    private javax.swing.JButton btnFinalizar;
    private javax.swing.JButton btnRemover;
    private javax.swing.JComboBox cbFormaPagamento;
    private javax.swing.JComboBox cbFornecedor;
    private javax.swing.JComboBox cbProduto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel lblValorTotal;
    private javax.swing.JPanel painelBotoesItens;
    private javax.swing.JPanel painelItens;
    private javax.swing.JPanel painelPrincipal;
    private javax.swing.JPanel painelRodape;
    private javax.swing.JPanel painelTopo;
    private javax.swing.JScrollPane scrollItens;
    private javax.swing.JSpinner spnParcelas;
    private javax.swing.JTable tabelaItens;
    private javax.swing.JTextField txtQuantidade;
    private javax.swing.JTextField txtValorUnitario;
    // End of variables declaration//GEN-END:variables

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        painelPrincipal = new javax.swing.JPanel();
        painelTopo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cbFornecedor = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        cbProduto = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        txtQuantidade = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtValorUnitario = new javax.swing.JTextField();
        btnAdicionar = new javax.swing.JButton();
        painelItens = new javax.swing.JPanel();
        scrollItens = new javax.swing.JScrollPane();
        tabelaItens = new javax.swing.JTable();
        painelBotoesItens = new javax.swing.JPanel();
        btnRemover = new javax.swing.JButton();
        painelRodape = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        lblValorTotal = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cbFormaPagamento = new javax.swing.JComboBox();
        jLabel7 = new javax.swing.JLabel();
        spnParcelas = new javax.swing.JSpinner();
        btnFinalizar = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Compra de Mercadorias");
        setPreferredSize(new java.awt.Dimension(820, 600));

        painelPrincipal.setLayout(new java.awt.BorderLayout());

        painelTopo.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados da compra"));
        painelTopo.setLayout(new java.awt.GridBagLayout());

        jLabel1.setText("Fornecedor:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelTopo.add(jLabel1, gridBagConstraints);

        cbFornecedor.setPreferredSize(new java.awt.Dimension(320, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelTopo.add(cbFornecedor, gridBagConstraints);

        jLabel2.setText("Produto:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelTopo.add(jLabel2, gridBagConstraints);

        cbProduto.setPreferredSize(new java.awt.Dimension(320, 28));
        cbProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbProdutoActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelTopo.add(cbProduto, gridBagConstraints);

        jLabel3.setText("Quantidade:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelTopo.add(jLabel3, gridBagConstraints);

        txtQuantidade.setColumns(8);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelTopo.add(txtQuantidade, gridBagConstraints);

        jLabel4.setText("Valor unitário:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelTopo.add(jLabel4, gridBagConstraints);

        txtValorUnitario.setColumns(10);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelTopo.add(txtValorUnitario, gridBagConstraints);

        btnAdicionar.setText("Adicionar produto");
        btnAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelTopo.add(btnAdicionar, gridBagConstraints);

        painelPrincipal.add(painelTopo, java.awt.BorderLayout.NORTH);

        painelItens.setBorder(javax.swing.BorderFactory.createTitledBorder("Produtos da compra"));
        painelItens.setLayout(new java.awt.BorderLayout());

        tabelaItens.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Produto", "Quantidade", "Valor unitário", "Subtotal"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        scrollItens.setViewportView(tabelaItens);

        painelItens.add(scrollItens, java.awt.BorderLayout.CENTER);

        painelBotoesItens.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnRemover.setText("Remover item selecionado");
        btnRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverActionPerformed(evt);
            }
        });
        painelBotoesItens.add(btnRemover);

        painelItens.add(painelBotoesItens, java.awt.BorderLayout.SOUTH);

        painelPrincipal.add(painelItens, java.awt.BorderLayout.CENTER);

        painelRodape.setBorder(javax.swing.BorderFactory.createTitledBorder("Pagamento"));
        painelRodape.setLayout(new java.awt.GridBagLayout());

        jLabel5.setText("Valor total:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelRodape.add(jLabel5, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelRodape.add(lblValorTotal, gridBagConstraints);

        jLabel6.setText("Forma de pagamento:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelRodape.add(jLabel6, gridBagConstraints);

        cbFormaPagamento.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "A VISTA", "A PRAZO" }));
        cbFormaPagamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbFormaPagamentoActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 0.6;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelRodape.add(cbFormaPagamento, gridBagConstraints);

        jLabel7.setText("Parcelas:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelRodape.add(jLabel7, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 0.2;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelRodape.add(spnParcelas, gridBagConstraints);

        btnFinalizar.setText("Finalizar compra");
        btnFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFinalizarActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        painelRodape.add(btnFinalizar, gridBagConstraints);

        painelPrincipal.add(painelRodape, java.awt.BorderLayout.SOUTH);

        getContentPane().add(painelPrincipal, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 1007, 524);
    }// </editor-fold>//GEN-END:initComponents

    private void cbProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbProdutoActionPerformed
        preencherValorUnitarioSugerido();
    }//GEN-LAST:event_cbProdutoActionPerformed

    private void btnAdicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdicionarActionPerformed
        adicionarProduto();
    }//GEN-LAST:event_btnAdicionarActionPerformed

    private void btnRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverActionPerformed
        removerItemSelecionado();
    }//GEN-LAST:event_btnRemoverActionPerformed

    private void cbFormaPagamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbFormaPagamentoActionPerformed
        atualizarEstadoParcelas();
    }//GEN-LAST:event_cbFormaPagamentoActionPerformed

    private void btnFinalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFinalizarActionPerformed
        finalizarCompra();
    }//GEN-LAST:event_btnFinalizarActionPerformed

    private void montarTabelaItens() {
        String[] colunas = {"Produto", "Quantidade", "Valor unitário", "Subtotal"};
        modeloItens = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabelaItens.setModel(modeloItens);
    }

    private void atualizarEstadoParcelas() {
        boolean aVista = "A VISTA".equals(cbFormaPagamento.getSelectedItem());
        if (aVista) {
            spnParcelas.setValue(1);
        }
        spnParcelas.setEnabled(!aVista);
    }

    private void carregarCombos() {
        cbFornecedor.removeAllItems();
        List<Fornecedor> fornecedores = fornecedorDAO.listarTodos().stream()
                .filter(Fornecedor::isAtivo)
                .collect(Collectors.toList());
        for (Fornecedor fornecedor : fornecedores) {
            cbFornecedor.addItem(fornecedor);
        }

        cbProduto.removeAllItems();
        List<Produto> produtos = produtoDAO.listarTodos().stream()
                .filter(Produto::isAtivo)
                .collect(Collectors.toList());
        for (Produto produto : produtos) {
            cbProduto.addItem(produto);
        }
    }

    /** Sugere o preço de custo cadastrado do produto ao selecioná-lo. */
    private void preencherValorUnitarioSugerido() {
        Produto produto = (Produto) cbProduto.getSelectedItem();
        if (produto != null && produto.getPrecoCusto() != null) {
            txtValorUnitario.setText(produto.getPrecoCusto().toString());
        }
    }

    private void adicionarProduto() {
        Produto produto = (Produto) cbProduto.getSelectedItem();
        if (produto == null) {
            JOptionPane.showMessageDialog(this, "Selecione um produto.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        BigDecimal quantidade = lerValorPositivo(txtQuantidade, "quantidade");
        if (quantidade == null) {
            return;
        }

        BigDecimal valorUnitario = lerValorPositivo(txtValorUnitario, "valor unitário");
        if (valorUnitario == null) {
            return;
        }

        ProdutoCompra item = new ProdutoCompra();
        item.setIdProduto(produto.getIdProduto());
        item.setDescricaoProduto(produto.getDescricao());
        item.setQuantidade(quantidade);
        item.setValorUnitario(valorUnitario);
        item.setSubtotal(quantidade.multiply(valorUnitario));

        itensCompra.add(item);
        modeloItens.addRow(new Object[]{
            item.getDescricaoProduto(), item.getQuantidade(),
            moeda.format(item.getValorUnitario()), moeda.format(item.getSubtotal())
        });

        recalcularValorTotal();

        txtQuantidade.setText("");
        txtValorUnitario.setText("");
    }

    private void removerItemSelecionado() {
        int linha = tabelaItens.getSelectedRow();
        if (linha < 0) {
            JOptionPane.showMessageDialog(this, "Selecione um item da lista para remover.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        itensCompra.remove(linha);
        modeloItens.removeRow(linha);
        recalcularValorTotal();
    }

    private void recalcularValorTotal() {
        valorTotal = BigDecimal.ZERO;
        for (ProdutoCompra item : itensCompra) {
            valorTotal = valorTotal.add(item.getSubtotal());
        }
        lblValorTotal.setText(moeda.format(valorTotal));
    }

    private BigDecimal lerValorPositivo(javax.swing.JTextField campo, String nomeCampo) {
        try {
            BigDecimal valor = new BigDecimal(campo.getText().trim().replace(",", "."));
            if (valor.compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(this, "Informe um(a) " + nomeCampo + " maior que zero.",
                        "Valor inválido", JOptionPane.WARNING_MESSAGE);
                return null;
            }
            return valor;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Informe um(a) " + nomeCampo + " válido(a).",
                    "Valor inválido", JOptionPane.WARNING_MESSAGE);
            return null;
        }
    }

    private void finalizarCompra() {
        Fornecedor fornecedor = (Fornecedor) cbFornecedor.getSelectedItem();
        if (fornecedor == null) {
            JOptionPane.showMessageDialog(this, "Selecione o fornecedor da compra.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (itensCompra.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Adicione ao menos um produto à compra.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Compra compra = new Compra();
        compra.setIdFornecedor(fornecedor.getIdFornecedor());
        compra.setIdUsuario(SessaoUsuario.getUsuario().getIdUsuario());
        compra.setDataCompra(LocalDate.now());
        compra.setFormaPagamento((String) cbFormaPagamento.getSelectedItem());
        compra.setQuantidadeParcelas((Integer) spnParcelas.getValue());
        compra.setValorTotal(valorTotal);
        compra.setItens(new ArrayList<>(itensCompra));

        boolean ok = compraService.finalizarCompra(compra);

        if (ok) {
            JOptionPane.showMessageDialog(this,
                    "Compra nº " + compra.getIdCompra() + " finalizada com sucesso.\n"
                            + "Estoque atualizado e contas a pagar geradas.");
            limparTela();
            carregarCombos();
        }
    }

    private void limparTela() {
        itensCompra.clear();
        modeloItens.setRowCount(0);
        recalcularValorTotal();
        txtQuantidade.setText("");
        txtValorUnitario.setText("");
        cbFormaPagamento.setSelectedIndex(0);
        atualizarEstadoParcelas();
    }
}