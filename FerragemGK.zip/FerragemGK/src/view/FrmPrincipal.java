package view;

import util.SessaoUsuario;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class FrmPrincipal extends javax.swing.JFrame {

    public FrmPrincipal() {
        initComponents();
        aplicarEstiloVisual();
        montarTelaDinamica();
    }

    private void montarTelaDinamica() {
        String nomeUsuario = SessaoUsuario.getUsuario() != null
                ? SessaoUsuario.getUsuario().getNome() : "";
        String nivel = SessaoUsuario.getUsuario() != null
                ? SessaoUsuario.getUsuario().getNivel() : "";

        setTitle("FerragemGK - " + nomeUsuario + " (" + nivel + ")");
        lblUsuario.setText(nomeUsuario.isEmpty()
                ? "Sessão ativa"
                : nomeUsuario + (nivel.isEmpty() ? "" : "  •  " + nivel));
        boolean master = SessaoUsuario.isMaster();
        itemUsuarios.setVisible(master);
        itemContasPagar.setVisible(master);
        setLocationRelativeTo(null);
        setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
    }

    private void aplicarEstiloVisual() {
        java.awt.Color fundo = new java.awt.Color(245, 243, 255);
        java.awt.Color cabecalho = new java.awt.Color(30, 27, 75);
        java.awt.Color textoSecundario = new java.awt.Color(100, 116, 139);

        desktopPane.setBackground(fundo);

        painelCabecalho.setBackground(cabecalho);
        lblTituloSistema.setForeground(java.awt.Color.WHITE);
        lblTituloSistema.setFont(lblTituloSistema.getFont().deriveFont(
                java.awt.Font.BOLD, 22f));

    

        lblUsuario.setForeground(java.awt.Color.WHITE);
        lblUsuario.setFont(lblUsuario.getFont().deriveFont(java.awt.Font.BOLD));

        painelStatus.setBackground(new java.awt.Color(250, 250, 255));
        painelStatus.setBorder(javax.swing.BorderFactory.createMatteBorder(
                1, 0, 0, 0, new java.awt.Color(221, 214, 254)));

        lblStatus.setForeground(textoSecundario);

        painelCabecalho.setBorder(javax.swing.BorderFactory.createEmptyBorder(
                12, 18, 12, 18));
        painelIdentidade.setOpaque(false);
        painelUsuario.setOpaque(false);
        painelStatus.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                painelStatus.getBorder(),
                javax.swing.BorderFactory.createEmptyBorder(6, 14, 6, 14)));
    }

    private void itemClientesActionPerformed(java.awt.event.ActionEvent evt) {
        abrirClientes();
    }

    private void itemFornecedoresActionPerformed(java.awt.event.ActionEvent evt) {
        abrirFornecedores();
    }

    private void itemProdutosActionPerformed(java.awt.event.ActionEvent evt) {
        abrirProdutos();
    }

    private void itemUsuariosActionPerformed(java.awt.event.ActionEvent evt) {
        abrirUsuarios();
    }

    private void itemComprasActionPerformed(java.awt.event.ActionEvent evt) {
        abrirCompras();
    }

    private void itemVendasActionPerformed(java.awt.event.ActionEvent evt) {
        abrirVendas();
    }

    private void itemContasPagarActionPerformed(java.awt.event.ActionEvent evt) {
        abrirContasPagar();
    }

    private void itemContasReceberActionPerformed(java.awt.event.ActionEvent evt) {
        abrirContasReceber();
    }

    private void itemConsultaComprasActionPerformed(java.awt.event.ActionEvent evt) {
        abrirConsultaCompras();
    }

    private void itemConsultaVendasActionPerformed(java.awt.event.ActionEvent evt) {
        abrirConsultaVendas();
    }

    private void itemSobreActionPerformed(java.awt.event.ActionEvent evt) {
        JOptionPane.showMessageDialog(this,
                "FerragemGK",
                "Sobre", JOptionPane.INFORMATION_MESSAGE);
    }

    private void itemSairActionPerformed(java.awt.event.ActionEvent evt) {
        int resposta = JOptionPane.showConfirmDialog(this,
                "Deseja realmente sair do sistema?", "Confirmação",
                JOptionPane.YES_NO_OPTION);
        if (resposta == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    public javax.swing.JDesktopPane getDesktopPane() {
        return desktopPane;
    }

    private void manterMaximizada(javax.swing.JInternalFrame frame) {
        if (frame == null || frame.isClosed()) {
            return;
        }

        try {
            if (!frame.isMaximum()) {
                frame.setMaximum(true);
            }
        } catch (java.beans.PropertyVetoException ex) {
            frame.setBounds(
                    0,
                    0,
                    desktopPane.getWidth(),
                    desktopPane.getHeight());
        }
    }

    private void instalarMaximizacaoPermanente(javax.swing.JInternalFrame frame) {
        frame.addPropertyChangeListener(
                javax.swing.JInternalFrame.IS_MAXIMUM_PROPERTY,
                evt -> {
                    if (Boolean.FALSE.equals(evt.getNewValue())) {
                        javax.swing.SwingUtilities.invokeLater(
                                () -> manterMaximizada(frame));
                    }
                });
    }

    private void abrirClientes() {
        for (java.awt.Component comp : desktopPane.getComponents()) {
            if (comp instanceof FrmCliente) {
                FrmCliente existente = (FrmCliente) comp;
                manterMaximizada(existente);
                try {
                    existente.setSelected(true);
                } catch (java.beans.PropertyVetoException ex) {
                }
                return;
            }
        }

        FrmCliente frmCliente = new FrmCliente();
        desktopPane.add(frmCliente);
        instalarMaximizacaoPermanente(frmCliente);
        frmCliente.setVisible(true);
        manterMaximizada(frmCliente);
        try {
            frmCliente.setSelected(true);
        } catch (java.beans.PropertyVetoException ex) {
        }
    }

    /** Abre a tela de Fornecedores, seguindo o mesmo padrão de abrirClientes(). */
    private void abrirFornecedores() {
        for (java.awt.Component comp : desktopPane.getComponents()) {
            if (comp instanceof FrmFornecedor) {
                FrmFornecedor existente = (FrmFornecedor) comp;
                manterMaximizada(existente);
                try {
                    existente.setSelected(true);
                } catch (java.beans.PropertyVetoException ex) {
                }
                return;
            }
        }

        FrmFornecedor frmFornecedor = new FrmFornecedor();
        desktopPane.add(frmFornecedor);
        instalarMaximizacaoPermanente(frmFornecedor);
        frmFornecedor.setVisible(true);
        manterMaximizada(frmFornecedor);
        try {
            frmFornecedor.setSelected(true);
        } catch (java.beans.PropertyVetoException ex) {
        }
    }

    private void abrirProdutos() {
        for (java.awt.Component comp : desktopPane.getComponents()) {
            if (comp instanceof FrmProduto) {
                FrmProduto existente = (FrmProduto) comp;
                manterMaximizada(existente);
                try {
                    existente.setSelected(true);
                } catch (java.beans.PropertyVetoException ex) {
                }
                return;
            }
        }

        FrmProduto frmProduto = new FrmProduto();
        desktopPane.add(frmProduto);
        instalarMaximizacaoPermanente(frmProduto);
        frmProduto.setVisible(true);
        manterMaximizada(frmProduto);
        try {
            frmProduto.setSelected(true);
        } catch (java.beans.PropertyVetoException ex) {
        }
    }

    private void abrirCompras() {
        for (java.awt.Component comp : desktopPane.getComponents()) {
            if (comp instanceof FrmCompra) {
                FrmCompra existente = (FrmCompra) comp;
               manterMaximizada(existente);
                manterMaximizada(existente);
                try {
                    existente.setSelected(true);
                } catch (java.beans.PropertyVetoException ex) {
                }
                return;
            }
        }

        FrmCompra frmCompra = new FrmCompra();
        desktopPane.add(frmCompra);
        instalarMaximizacaoPermanente(frmCompra);

        frmCompra.addPropertyChangeListener(
                javax.swing.JInternalFrame.IS_MAXIMUM_PROPERTY,
                evt -> {
                    if (Boolean.FALSE.equals(evt.getNewValue())) {
                        javax.swing.SwingUtilities.invokeLater(
                                () -> manterMaximizada(frmCompra));
                    }
                });

        frmCompra.setVisible(true);
        manterMaximizada(frmCompra);

        try {
            frmCompra.setSelected(true);
        } catch (java.beans.PropertyVetoException ex) {
        }
    }
    
    private void maximizarCompra(FrmCompra frmCompra) {
        if (frmCompra == null || frmCompra.isClosed()) {
            return;
        }

        try {
            if (!frmCompra.isMaximum()) {
                frmCompra.setMaximum(true);
            }
        } catch (java.beans.PropertyVetoException ex) {
            frmCompra.setBounds(
                    0,
                    0,
                    desktopPane.getWidth(),
                    desktopPane.getHeight());
        }
    }

    private void abrirVendas() {
        for (java.awt.Component comp : desktopPane.getComponents()) {
            if (comp instanceof FrmVenda) {
                FrmVenda existente = (FrmVenda) comp;
                manterMaximizada(existente);
                try {
                    existente.setSelected(true);
                } catch (java.beans.PropertyVetoException ex) {
                }
                return;
            }
        }

        FrmVenda frmVenda = new FrmVenda();
        desktopPane.add(frmVenda);
        instalarMaximizacaoPermanente(frmVenda);
        frmVenda.setVisible(true);
        manterMaximizada(frmVenda);
        try {
            frmVenda.setSelected(true);
        } catch (java.beans.PropertyVetoException ex) {
        }
    }
    
    private void abrirContasPagar() {
        for (java.awt.Component comp : desktopPane.getComponents()) {
            if (comp instanceof FrmContasPagar) {
                FrmContasPagar existente = (FrmContasPagar) comp;
                manterMaximizada(existente);
                try {
                    existente.setSelected(true);
                } catch (java.beans.PropertyVetoException ex) {
                }
                return;
            }
        }

        FrmContasPagar frmContasPagar = new FrmContasPagar();
        desktopPane.add(frmContasPagar);
        instalarMaximizacaoPermanente(frmContasPagar);
        frmContasPagar.setVisible(true);
        manterMaximizada(frmContasPagar);
        try {
            frmContasPagar.setSelected(true);
        } catch (java.beans.PropertyVetoException ex) {
        }
    }

    private void abrirContasReceber() {
        for (java.awt.Component comp : desktopPane.getComponents()) {
            if (comp instanceof FrmContasReceber) {
                FrmContasReceber existente = (FrmContasReceber) comp;
                manterMaximizada(existente);
                try {
                    existente.setSelected(true);
                } catch (java.beans.PropertyVetoException ex) {
                }
                return;
            }
        }

        FrmContasReceber frmContasReceber = new FrmContasReceber();
        desktopPane.add(frmContasReceber);
        instalarMaximizacaoPermanente(frmContasReceber);
        frmContasReceber.setVisible(true);
        manterMaximizada(frmContasReceber);
        try {
            frmContasReceber.setSelected(true);
        } catch (java.beans.PropertyVetoException ex) {
        }
    }

    private void abrirConsultaCompras() {
        for (java.awt.Component comp : desktopPane.getComponents()) {
            if (comp instanceof FrmConsultaCompras) {
                FrmConsultaCompras existente = (FrmConsultaCompras) comp;
                manterMaximizada(existente);
                try {
                    existente.setSelected(true);
                } catch (java.beans.PropertyVetoException ex) {
                }
                return;
            }
        }

        FrmConsultaCompras frmConsultaCompras = new FrmConsultaCompras();
        desktopPane.add(frmConsultaCompras);
        instalarMaximizacaoPermanente(frmConsultaCompras);
        frmConsultaCompras.setVisible(true);
        manterMaximizada(frmConsultaCompras);
        try {
            frmConsultaCompras.setSelected(true);
        } catch (java.beans.PropertyVetoException ex) {
        }
    }

    private void abrirConsultaVendas() {
        for (java.awt.Component comp : desktopPane.getComponents()) {
            if (comp instanceof FrmConsultaVendas) {
                FrmConsultaVendas existente = (FrmConsultaVendas) comp;
                manterMaximizada(existente);
                try {
                    existente.setSelected(true);
                } catch (java.beans.PropertyVetoException ex) {
                }
                return;
            }
        }

        FrmConsultaVendas frmConsultaVendas = new FrmConsultaVendas();
        desktopPane.add(frmConsultaVendas);
        instalarMaximizacaoPermanente(frmConsultaVendas);
        frmConsultaVendas.setVisible(true);
        manterMaximizada(frmConsultaVendas);
        try {
            frmConsultaVendas.setSelected(true);
        } catch (java.beans.PropertyVetoException ex) {
        }
    }

    private JMenuItem criarItemUsuarios() {
        JMenuItem item = new JMenuItem("Usuários");
        item.addActionListener(e -> abrirUsuarios());
        return item;
    }

    private void abrirUsuarios() {
        for (java.awt.Component comp : desktopPane.getComponents()) {
            if (comp instanceof FrmUsuario) {
                FrmUsuario existente = (FrmUsuario) comp;
                manterMaximizada(existente);
                try {
                    existente.setSelected(true);
                } catch (java.beans.PropertyVetoException ex) {
                }
                return;
            }
        }

        FrmUsuario frmUsuario = new FrmUsuario();
        desktopPane.add(frmUsuario);
        instalarMaximizacaoPermanente(frmUsuario);
        frmUsuario.setVisible(true);
        manterMaximizada(frmUsuario);
        try {
            frmUsuario.setSelected(true);
        } catch (java.beans.PropertyVetoException ex) {
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        desktopPane = new javax.swing.JDesktopPane();
        painelStatus = new javax.swing.JPanel();
        painelCabecalho = new javax.swing.JPanel();
        painelIdentidade = new javax.swing.JPanel();
        lblTituloSistema = new javax.swing.JLabel();
        painelUsuario = new javax.swing.JPanel();
        lblUsuario = new javax.swing.JLabel();
        lblStatus = new javax.swing.JLabel();
        menuBarPrincipal = new javax.swing.JMenuBar();
        menuSistema = new javax.swing.JMenu();
        itemSair = new javax.swing.JMenuItem();
        menuCadastros = new javax.swing.JMenu();
        itemClientes = new javax.swing.JMenuItem();
        itemFornecedores = new javax.swing.JMenuItem();
        itemProdutos = new javax.swing.JMenuItem();
        separadorCadastros = new javax.swing.JPopupMenu.Separator();
        itemUsuarios = new javax.swing.JMenuItem();
        menuMovimentos = new javax.swing.JMenu();
        itemCompras = new javax.swing.JMenuItem();
        itemVendas = new javax.swing.JMenuItem();
        menuFinanceiro = new javax.swing.JMenu();
        itemContasPagar = new javax.swing.JMenuItem();
        itemContasReceber = new javax.swing.JMenuItem();
        menuConsultas = new javax.swing.JMenu();
        itemConsultaCompras = new javax.swing.JMenuItem();
        itemConsultaVendas = new javax.swing.JMenuItem();
        menuAjuda = new javax.swing.JMenu();
        itemSobre = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(900, 600));

        desktopPane.setForeground(new java.awt.Color(0, 0, 255));
        getContentPane().add(desktopPane, java.awt.BorderLayout.CENTER);

        painelStatus.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        painelCabecalho.setLayout(new java.awt.BorderLayout());

        painelIdentidade.setLayout(new java.awt.BorderLayout());

        lblTituloSistema.setForeground(new java.awt.Color(255, 153, 51));
        lblTituloSistema.setText("FerragemGK");
        painelIdentidade.add(lblTituloSistema, java.awt.BorderLayout.NORTH);

        painelCabecalho.add(painelIdentidade, java.awt.BorderLayout.WEST);

        painelUsuario.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));
        painelCabecalho.add(painelUsuario, java.awt.BorderLayout.EAST);

        painelStatus.add(painelCabecalho);

        lblUsuario.setForeground(new java.awt.Color(255, 102, 102));
        lblUsuario.setText("Sessão ativa");
        painelStatus.add(lblUsuario);

        getContentPane().add(painelStatus, java.awt.BorderLayout.PAGE_START);

        lblStatus.setText("Pronto");
        getContentPane().add(lblStatus, java.awt.BorderLayout.PAGE_END);

        menuSistema.setText("Sistema");

        itemSair.setText("Sair");
        itemSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemSairActionPerformed(evt);
            }
        });
        menuSistema.add(itemSair);

        menuBarPrincipal.add(menuSistema);

        menuCadastros.setText("Cadastros");

        itemClientes.setText("Clientes");
        itemClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemClientesActionPerformed(evt);
            }
        });
        menuCadastros.add(itemClientes);

        itemFornecedores.setText("Fornecedores");
        itemFornecedores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemFornecedoresActionPerformed(evt);
            }
        });
        menuCadastros.add(itemFornecedores);

        itemProdutos.setText("Produtos");
        itemProdutos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemProdutosActionPerformed(evt);
            }
        });
        menuCadastros.add(itemProdutos);
        menuCadastros.add(separadorCadastros);

        itemUsuarios.setText("Usuários");
        itemUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemUsuariosActionPerformed(evt);
            }
        });
        menuCadastros.add(itemUsuarios);

        menuBarPrincipal.add(menuCadastros);

        menuMovimentos.setText("Movimentos");

        itemCompras.setText("Compras");
        itemCompras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemComprasActionPerformed(evt);
            }
        });
        menuMovimentos.add(itemCompras);

        itemVendas.setText("Vendas");
        itemVendas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemVendasActionPerformed(evt);
            }
        });
        menuMovimentos.add(itemVendas);

        menuBarPrincipal.add(menuMovimentos);

        menuFinanceiro.setText("Financeiro");

        itemContasPagar.setText("Contas a pagar");
        itemContasPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemContasPagarActionPerformed(evt);
            }
        });
        menuFinanceiro.add(itemContasPagar);

        itemContasReceber.setText("Contas a receber");
        itemContasReceber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemContasReceberActionPerformed(evt);
            }
        });
        menuFinanceiro.add(itemContasReceber);

        menuBarPrincipal.add(menuFinanceiro);

        menuConsultas.setText("Consultas");

        itemConsultaCompras.setText("Compras realizadas");
        itemConsultaCompras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemConsultaComprasActionPerformed(evt);
            }
        });
        menuConsultas.add(itemConsultaCompras);

        itemConsultaVendas.setText("Vendas realizadas");
        itemConsultaVendas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemConsultaVendasActionPerformed(evt);
            }
        });
        menuConsultas.add(itemConsultaVendas);

        menuBarPrincipal.add(menuConsultas);

        menuAjuda.setText("Ajuda");

        itemSobre.setText("Sobre");
        itemSobre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemSobreActionPerformed(evt);
            }
        });
        menuAjuda.add(itemSobre);

        menuBarPrincipal.add(menuAjuda);

        setJMenuBar(menuBarPrincipal);

        setBounds(0, 0, 484, 467);
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane desktopPane;
    private javax.swing.JMenuItem itemClientes;
    private javax.swing.JMenuItem itemCompras;
    private javax.swing.JMenuItem itemConsultaCompras;
    private javax.swing.JMenuItem itemConsultaVendas;
    private javax.swing.JMenuItem itemContasPagar;
    private javax.swing.JMenuItem itemContasReceber;
    private javax.swing.JMenuItem itemFornecedores;
    private javax.swing.JMenuItem itemProdutos;
    private javax.swing.JMenuItem itemSair;
    private javax.swing.JMenuItem itemSobre;
    private javax.swing.JMenuItem itemUsuarios;
    private javax.swing.JMenuItem itemVendas;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblTituloSistema;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JMenu menuAjuda;
    private javax.swing.JMenuBar menuBarPrincipal;
    private javax.swing.JMenu menuCadastros;
    private javax.swing.JMenu menuConsultas;
    private javax.swing.JMenu menuFinanceiro;
    private javax.swing.JMenu menuMovimentos;
    private javax.swing.JMenu menuSistema;
    private javax.swing.JPanel painelCabecalho;
    private javax.swing.JPanel painelIdentidade;
    private javax.swing.JPanel painelStatus;
    private javax.swing.JPanel painelUsuario;
    private javax.swing.JPopupMenu.Separator separadorCadastros;
    // End of variables declaration//GEN-END:variables
}