package view;

import dao.ClienteDAO;
import model.Cliente;
import util.Permissao;
import util.Validacao;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class FrmCliente extends javax.swing.JInternalFrame {

    private final ClienteDAO clienteDAO = new ClienteDAO();
    private DefaultTableModel modeloTabela;
    private Integer idClienteEmEdicao = null;

    public FrmCliente() {
        initComponents();
        aplicarEstiloVisual();
        montarTabela();
        listarTodos();
    }

    private void aplicarEstiloVisual() {
        java.awt.Color fundo = new java.awt.Color(245, 243, 255);
        java.awt.Color textoLabel = new java.awt.Color(49, 46, 129);
        java.awt.Color headerTabela = new java.awt.Color(67, 56, 202);
        java.awt.Color corPrimaria = new java.awt.Color(79, 70, 229);
        java.awt.Color corPerigo = new java.awt.Color(225, 29, 72);
        java.awt.Color corNeutra = new java.awt.Color(100, 116, 139);

        painelCadastro.setBackground(fundo);
        painelConsulta.setBackground(fundo);
        painelFiltro.setBackground(fundo);
        painelBotoes.setBackground(fundo);
        tabbedPane.setBackground(fundo);

        for (javax.swing.JLabel lbl : new javax.swing.JLabel[]{
            lblId, lblNome, lblCpf, lblTelefone, lblEmail, lblEndereco,
            lblCidade, lblUf, lblCep, lblFiltro, lblPesquisa}) {
            lbl.setForeground(textoLabel);
            lbl.setFont(lbl.getFont().deriveFont(java.awt.Font.BOLD));
        }

        for (javax.swing.JButton btn : new javax.swing.JButton[]{
            btnNovo, btnSalvar, btnAlterar, btnLocalizar, btnListarTodos}) {
            btn.setBackground(corPrimaria);
            btn.setForeground(java.awt.Color.WHITE);
            btn.setFont(btn.getFont().deriveFont(java.awt.Font.BOLD));
        }
        btnExcluir.setBackground(corPerigo);
        btnExcluir.setForeground(java.awt.Color.WHITE);
        btnExcluir.setFont(btnExcluir.getFont().deriveFont(java.awt.Font.BOLD));
        btnCancelar.setBackground(corNeutra);
        btnCancelar.setForeground(java.awt.Color.WHITE);
        btnCancelar.setFont(btnCancelar.getFont().deriveFont(java.awt.Font.BOLD));

        tabela.getTableHeader().setBackground(headerTabela);
        tabela.getTableHeader().setForeground(java.awt.Color.WHITE);
        tabela.setSelectionBackground(corPrimaria);
        tabela.setSelectionForeground(java.awt.Color.WHITE);
        tabela.setGridColor(new java.awt.Color(237, 233, 254));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnListarTodos;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JComboBox cbFiltro;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JLabel lblCep;
    private javax.swing.JLabel lblCidade;
    private javax.swing.JLabel lblCpf;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblEndereco;
    private javax.swing.JLabel lblFiltro;
    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblPesquisa;
    private javax.swing.JLabel lblTelefone;
    private javax.swing.JLabel lblUf;
    private javax.swing.JPanel painelBotoes;
    private javax.swing.JPanel painelCadastro;
    private javax.swing.JPanel painelConsulta;
    private javax.swing.JPanel painelFiltro;
    private javax.swing.JScrollPane scrollTabela;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JTable tabela;
    private javax.swing.JTextField txtCep;
    private javax.swing.JTextField txtCidade;
    private javax.swing.JTextField txtCpf;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtPesquisa;
    private javax.swing.JTextField txtTelefone;
    private javax.swing.JTextField txtUf;
    // End of variables declaration//GEN-END:variables

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        tabbedPane = new javax.swing.JTabbedPane();
        painelCadastro = new javax.swing.JPanel();
        lblId = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        lblNome = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        lblCpf = new javax.swing.JLabel();
        txtCpf = new javax.swing.JTextField();
        lblTelefone = new javax.swing.JLabel();
        txtTelefone = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        lblEndereco = new javax.swing.JLabel();
        txtEndereco = new javax.swing.JTextField();
        lblCidade = new javax.swing.JLabel();
        txtCidade = new javax.swing.JTextField();
        lblUf = new javax.swing.JLabel();
        txtUf = new javax.swing.JTextField();
        lblCep = new javax.swing.JLabel();
        txtCep = new javax.swing.JTextField();
        painelBotoes = new javax.swing.JPanel();
        btnNovo = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        btnAlterar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        chkAtivo = new javax.swing.JCheckBox();
        painelConsulta = new javax.swing.JPanel();
        painelFiltro = new javax.swing.JPanel();
        lblFiltro = new javax.swing.JLabel();
        cbFiltro = new javax.swing.JComboBox();
        lblPesquisa = new javax.swing.JLabel();
        txtPesquisa = new javax.swing.JTextField();
        btnLocalizar = new javax.swing.JButton();
        btnListarTodos = new javax.swing.JButton();
        scrollTabela = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Clientes");

        painelCadastro.setLayout(new java.awt.GridBagLayout());

        lblId.setText("Código:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblId, gridBagConstraints);

        txtId.setEditable(false);
        txtId.setColumns(5);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtId, gridBagConstraints);

        lblNome.setText("Nome:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblNome, gridBagConstraints);

        txtNome.setColumns(25);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtNome, gridBagConstraints);

        lblCpf.setText("CPF:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblCpf, gridBagConstraints);

        txtCpf.setColumns(15);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtCpf, gridBagConstraints);

        lblTelefone.setText("Telefone:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblTelefone, gridBagConstraints);

        txtTelefone.setColumns(15);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtTelefone, gridBagConstraints);

        lblEmail.setText("Email:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblEmail, gridBagConstraints);

        txtEmail.setColumns(25);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtEmail, gridBagConstraints);

        lblEndereco.setText("Endereço:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblEndereco, gridBagConstraints);

        txtEndereco.setColumns(25);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtEndereco, gridBagConstraints);

        lblCidade.setText("Cidade:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblCidade, gridBagConstraints);

        txtCidade.setColumns(20);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtCidade, gridBagConstraints);

        lblUf.setText("UF:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblUf, gridBagConstraints);

        txtUf.setColumns(2);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtUf, gridBagConstraints);

        lblCep.setText("CEP:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblCep, gridBagConstraints);

        txtCep.setColumns(10);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtCep, gridBagConstraints);

        painelBotoes.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        btnNovo.setText("Novo");
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoActionPerformed(evt);
            }
        });
        painelBotoes.add(btnNovo);

        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });
        painelBotoes.add(btnSalvar);

        btnAlterar.setText("Alterar");
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });
        painelBotoes.add(btnAlterar);

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });
        painelBotoes.add(btnExcluir);

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        painelBotoes.add(btnCancelar);

        chkAtivo.setSelected(true);
        chkAtivo.setText("Ativo");
        painelBotoes.add(chkAtivo);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(painelBotoes, gridBagConstraints);

        tabbedPane.addTab("Cadastro", painelCadastro);

        painelConsulta.setLayout(new java.awt.BorderLayout());

        painelFiltro.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        lblFiltro.setText("Filtro:");
        painelFiltro.add(lblFiltro);

        cbFiltro.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "NOME", "ID", "CPF", "EMAIL" }));
        cbFiltro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbFiltroActionPerformed(evt);
            }
        });
        painelFiltro.add(cbFiltro);

        lblPesquisa.setText("Pesquisa:");
        painelFiltro.add(lblPesquisa);

        txtPesquisa.setColumns(15);
        painelFiltro.add(txtPesquisa);

        btnLocalizar.setText("Localizar");
        btnLocalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLocalizarActionPerformed(evt);
            }
        });
        painelFiltro.add(btnLocalizar);

        btnListarTodos.setText("Listar todos");
        btnListarTodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarTodosActionPerformed(evt);
            }
        });
        painelFiltro.add(btnListarTodos);

        painelConsulta.add(painelFiltro, java.awt.BorderLayout.NORTH);

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nome", "CPF", "Telefone", "Email", "Cidade", "UF", "Ativo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabela.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tabelaMouseReleased(evt);
            }
        });
        scrollTabela.setViewportView(tabela);

        painelConsulta.add(scrollTabela, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Consulta", painelConsulta);

        getContentPane().add(tabbedPane, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 970, 483);
    }// </editor-fold>//GEN-END:initComponents

    private void tabelaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaMouseReleased
        if (tabela.getSelectedRow() >= 0) {
            carregarSelecionado();
        }
    }//GEN-LAST:event_tabelaMouseReleased

    private void btnListarTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarTodosActionPerformed
        listarTodos();
    }//GEN-LAST:event_btnListarTodosActionPerformed

    private void btnLocalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLocalizarActionPerformed
        pesquisar();
    }//GEN-LAST:event_btnLocalizarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        limparCampos();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        excluir();
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        alterar();
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        salvar();
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoActionPerformed
        limparCampos();
    }//GEN-LAST:event_btnNovoActionPerformed

    private void cbFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbFiltroActionPerformed
    }//GEN-LAST:event_cbFiltroActionPerformed


    private void montarTabela() {
        String[] colunas = {"Código", "Nome", "CPF", "Telefone", "Email", "Cidade", "UF", "Ativo"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabela.setModel(modeloTabela);
    }

    private void salvar() {
        // Se existe um cliente carregado para edição, nunca cria um novo registro.
        // Isso evita duplicação acidental ao salvar um cadastro já selecionado.
        if (idClienteEmEdicao != null || !txtId.getText().trim().isEmpty()) {
            alterar();
            return;
        }

        if (!validarCampos()) {
            return;
        }

        Cliente cliente = montarClienteDosCampos();
        boolean ok = clienteDAO.inserir(cliente);

        if (ok) {
            javax.swing.JOptionPane.showMessageDialog(this, "Cliente cadastrado com sucesso.");
            limparCampos();
            listarTodos();
        }
    }

    private void alterar() {
        Integer id = idClienteEmEdicao;
        if (id == null && !txtId.getText().trim().isEmpty()) {
            try {
                id = Integer.valueOf(txtId.getText().trim());
            } catch (NumberFormatException e) {
                id = null;
            }
        }

        if (id == null) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Selecione um cliente na aba Consulta antes de alterar.",
                    "Atenção", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!validarCampos()) {
            return;
        }

        Cliente cliente = montarClienteDosCampos();
        cliente.setIdCliente(id);
        boolean ok = clienteDAO.alterar(cliente);

        if (ok) {
            javax.swing.JOptionPane.showMessageDialog(this, "Cliente alterado com sucesso.");
            limparCampos();
            listarTodos();
        }
    }

    private void excluir() {
        if (!Permissao.exigirMaster()) {
            return;
        }
        if (txtId.getText().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Selecione um cliente na aba Consulta antes de excluir.",
                    "Atenção", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }

        int resposta = javax.swing.JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir o cliente \"" + txtNome.getText() + "\"?",
                "Confirmação", javax.swing.JOptionPane.YES_NO_OPTION);

        if (resposta == javax.swing.JOptionPane.YES_OPTION) {
            boolean ok = clienteDAO.excluir(Integer.parseInt(txtId.getText()));
            if (ok) {
                javax.swing.JOptionPane.showMessageDialog(this, "Cliente excluído com sucesso.");
                limparCampos();
                listarTodos();
            }
        }
    }

    private void listarTodos() {
        preencherTabela(clienteDAO.listarTodos());
    }

    private void pesquisar() {
        String filtro = (String) cbFiltro.getSelectedItem();
        String texto = txtPesquisa.getText();
        preencherTabela(clienteDAO.pesquisar(filtro, texto));
    }

    private void preencherTabela(List<Cliente> clientes) {
        modeloTabela.setRowCount(0);
        for (Cliente c : clientes) {
            modeloTabela.addRow(new Object[]{
                c.getIdCliente(), c.getNome(), c.getCpf(), c.getTelefone(),
                c.getEmail(), c.getCidade(), c.getUf(), c.isAtivo() ? "Sim" : "Não"
            });
        }
    }

    private void carregarSelecionado() {
        int linha = tabela.getSelectedRow();
        if (linha < 0) {
            return;
        }

        int id = Integer.parseInt(modeloTabela.getValueAt(linha, 0).toString());
        Cliente cliente = clienteDAO.buscarPorId(id);
        if (cliente == null) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Não foi possível carregar o cliente selecionado.",
                    "Atenção", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }

        idClienteEmEdicao = cliente.getIdCliente();
        txtId.setText(String.valueOf(cliente.getIdCliente()));
        txtNome.setText(valorOuVazio(cliente.getNome()));
        txtCpf.setText(valorOuVazio(cliente.getCpf()));
        txtTelefone.setText(valorOuVazio(cliente.getTelefone()));
        txtEmail.setText(valorOuVazio(cliente.getEmail()));
        txtEndereco.setText(valorOuVazio(cliente.getEndereco()));
        txtCidade.setText(valorOuVazio(cliente.getCidade()));
        txtUf.setText(valorOuVazio(cliente.getUf()));
        txtCep.setText(valorOuVazio(cliente.getCep()));
        chkAtivo.setSelected(cliente.isAtivo());

        tabbedPane.setSelectedIndex(0);
    }

    private String valorOuVazio(String valor) {
        return valor == null ? "" : valor;
    }

    private boolean validarCampos() {
        if (txtNome.getText().trim().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Informe o nome do cliente.",
                    "Campo obrigatório", javax.swing.JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (!Validacao.isEmailValido(txtEmail.getText())) {
            javax.swing.JOptionPane.showMessageDialog(this, "O email informado não é válido.",
                    "Email inválido", javax.swing.JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private Cliente montarClienteDosCampos() {
        Cliente cliente = new Cliente();
        cliente.setNome(txtNome.getText().trim());
        cliente.setCpf(txtCpf.getText().trim());
        cliente.setTelefone(txtTelefone.getText().trim());
        cliente.setEmail(txtEmail.getText().trim());
        cliente.setEndereco(txtEndereco.getText().trim());
        cliente.setCidade(txtCidade.getText().trim());
        cliente.setUf(txtUf.getText().trim());
        cliente.setCep(txtCep.getText().trim());
        cliente.setAtivo(chkAtivo.isSelected());
        return cliente;
    }

    private void limparCampos() {
        idClienteEmEdicao = null;
        txtId.setText("");
        txtNome.setText("");
        txtCpf.setText("");
        txtTelefone.setText("");
        txtEmail.setText("");
        txtEndereco.setText("");
        txtCidade.setText("");
        txtUf.setText("");
        txtCep.setText("");
        chkAtivo.setSelected(true);
    }
}