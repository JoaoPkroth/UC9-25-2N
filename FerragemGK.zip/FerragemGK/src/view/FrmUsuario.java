package view;

import dao.UsuarioDAO;
import model.Usuario;
import util.SessaoUsuario;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrmUsuario extends javax.swing.JInternalFrame {

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();
    private DefaultTableModel modeloTabela;

    public FrmUsuario() {
        initComponents();
        aplicarEstiloVisual();
        configurarTabela();
        tabela.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabela.getSelectedRow() >= 0) {
                carregarSelecionado();
            }
        });
        listarTodos();
    }

    private void aplicarEstiloVisual() {
        java.awt.Color fundo = new java.awt.Color(245, 243, 255);
        java.awt.Color textoLabel = new java.awt.Color(49, 46, 129);
        java.awt.Color headerTabela = new java.awt.Color(67, 56, 202);
        java.awt.Color corPrimaria = new java.awt.Color(79, 70, 229);
        java.awt.Color corPerigo = new java.awt.Color(225, 29, 72);
        java.awt.Color corNeutra = new java.awt.Color(100, 116, 139);

        panelCadastro.setBackground(fundo);
        panelConsulta.setBackground(fundo);
        painelFiltro.setBackground(fundo);
        painelBotoes.setBackground(fundo);
        tabbedPane.setBackground(fundo);

        for (javax.swing.JLabel lbl : new javax.swing.JLabel[]{
            lblCodigo, lblNome, lblLogin, lblSenha, lblDica, lblNivel,
            lblFiltro, lblPesquisa}) {
            lbl.setForeground(textoLabel);
            lbl.setFont(lbl.getFont().deriveFont(java.awt.Font.BOLD));
        }

        for (javax.swing.JButton btn : new javax.swing.JButton[]{
            btnNovo, btnSalvar, btnAlterar, btnLocalizar, btnListarTodos}) {
            btn.setBackground(corPrimaria);
            btn.setForeground(java.awt.Color.WHITE);
            btn.setFont(btn.getFont().deriveFont(java.awt.Font.BOLD));
        }
        btnExcluir.setBackground(corPerigo);
        btnExcluir.setForeground(java.awt.Color.WHITE);
        btnExcluir.setFont(btnExcluir.getFont().deriveFont(java.awt.Font.BOLD));
        btnCancelar.setBackground(corNeutra);
        btnCancelar.setForeground(java.awt.Color.WHITE);
        btnCancelar.setFont(btnCancelar.getFont().deriveFont(java.awt.Font.BOLD));

        tabela.getTableHeader().setBackground(headerTabela);
        tabela.getTableHeader().setForeground(java.awt.Color.WHITE);
        tabela.setSelectionBackground(corPrimaria);
        tabela.setSelectionForeground(java.awt.Color.WHITE);
        tabela.setGridColor(new java.awt.Color(237, 233, 254));
    }

    private void configurarTabela() {
        String[] colunas = {"Código", "Nome", "Login", "Nível", "Ativo"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabela.setModel(modeloTabela);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        tabbedPane = new javax.swing.JTabbedPane();
        panelConsulta = new javax.swing.JPanel();
        painelFiltro = new javax.swing.JPanel();
        lblFiltro = new javax.swing.JLabel();
        cbFiltro = new javax.swing.JComboBox();
        lblPesquisa = new javax.swing.JLabel();
        txtPesquisa = new javax.swing.JTextField();
        btnLocalizar = new javax.swing.JButton();
        btnListarTodos = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        panelCadastro = new javax.swing.JPanel();
        lblCodigo = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        lblNome = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        lblLogin = new javax.swing.JLabel();
        txtLogin = new javax.swing.JTextField();
        lblSenha = new javax.swing.JLabel();
        txtSenha = new javax.swing.JPasswordField();
        lblDica = new javax.swing.JLabel();
        lblNivel = new javax.swing.JLabel();
        cbNivel = new javax.swing.JComboBox();
        chkAtivo = new javax.swing.JCheckBox();
        painelBotoes = new javax.swing.JPanel();
        btnNovo = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        btnAlterar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Usuários");
        setPreferredSize(new java.awt.Dimension(700, 500));

        panelConsulta.setLayout(new java.awt.BorderLayout());

        painelFiltro.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));

        lblFiltro.setText("Filtro:");
        painelFiltro.add(lblFiltro);

        cbFiltro.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "NOME", "LOGIN", "ID" }));
        painelFiltro.add(cbFiltro);

        lblPesquisa.setText("Pesquisa:");
        painelFiltro.add(lblPesquisa);

        txtPesquisa.setColumns(15);
        painelFiltro.add(txtPesquisa);

        btnLocalizar.setText("Localizar");
        btnLocalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLocalizarActionPerformed(evt);
            }
        });
        painelFiltro.add(btnLocalizar);

        btnListarTodos.setText("Listar todos");
        btnListarTodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarTodosActionPerformed(evt);
            }
        });
        painelFiltro.add(btnListarTodos);

        panelConsulta.add(painelFiltro, java.awt.BorderLayout.NORTH);

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nome", "Login", "Nível", "Ativo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabela);

        panelConsulta.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Consulta", panelConsulta);

        panelCadastro.setLayout(new java.awt.GridBagLayout());

        lblCodigo.setText("Código:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(lblCodigo, gridBagConstraints);

        txtId.setEditable(false);
        txtId.setColumns(8);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(txtId, gridBagConstraints);

        lblNome.setText("Nome:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(lblNome, gridBagConstraints);

        txtNome.setColumns(25);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(txtNome, gridBagConstraints);

        lblLogin.setText("Login:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(lblLogin, gridBagConstraints);

        txtLogin.setColumns(20);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(txtLogin, gridBagConstraints);

        lblSenha.setText("Senha:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 2, 8);
        panelCadastro.add(lblSenha, gridBagConstraints);

        txtSenha.setColumns(20);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 2, 8);
        panelCadastro.add(txtSenha, gridBagConstraints);

        lblDica.setText("(deixe em branco para manter a senha atual ao alterar)");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 8, 6, 8);
        panelCadastro.add(lblDica, gridBagConstraints);

        lblNivel.setText("Nível:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(lblNivel, gridBagConstraints);

        cbNivel.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "USER", "MASTER" }));
        cbNivel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbNivelActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(cbNivel, gridBagConstraints);

        chkAtivo.setSelected(true);
        chkAtivo.setText("Ativo");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(chkAtivo, gridBagConstraints);

        painelBotoes.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnNovo.setText("Novo");
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoActionPerformed(evt);
            }
        });
        painelBotoes.add(btnNovo);

        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });
        painelBotoes.add(btnSalvar);

        btnAlterar.setText("Alterar");
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });
        painelBotoes.add(btnAlterar);

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });
        painelBotoes.add(btnExcluir);

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        painelBotoes.add(btnCancelar);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 8, 6, 8);
        panelCadastro.add(painelBotoes, gridBagConstraints);

        tabbedPane.addTab("Cadastro", panelCadastro);

        getContentPane().add(tabbedPane, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 837, 495);
    }// </editor-fold>//GEN-END:initComponents

    private void cbNivelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbNivelActionPerformed
    }//GEN-LAST:event_cbNivelActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnListarTodos;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JComboBox cbFiltro;
    private javax.swing.JComboBox cbNivel;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCodigo;
    private javax.swing.JLabel lblDica;
    private javax.swing.JLabel lblFiltro;
    private javax.swing.JLabel lblLogin;
    private javax.swing.JLabel lblNivel;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblPesquisa;
    private javax.swing.JLabel lblSenha;
    private javax.swing.JPanel painelBotoes;
    private javax.swing.JPanel painelFiltro;
    private javax.swing.JPanel panelCadastro;
    private javax.swing.JPanel panelConsulta;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JTable tabela;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtLogin;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtPesquisa;
    private javax.swing.JPasswordField txtSenha;
    // End of variables declaration//GEN-END:variables

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {
        limparCampos();
    }

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {
        salvar();
    }

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {
        alterar();
    }

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {
        excluir();
    }

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {
        limparCampos();
    }

    private void btnLocalizarActionPerformed(java.awt.event.ActionEvent evt) {
        pesquisar();
    }

    private void btnListarTodosActionPerformed(java.awt.event.ActionEvent evt) {
        listarTodos();
    }

    private void salvar() {
        if (!exigirMasterNestaTela()) {
            return;
        }

        String senha = new String(txtSenha.getPassword());
        if (!validarCampos(true, senha)) {
            return;
        }

        Usuario usuario = montarUsuarioDosCampos(senha);
        boolean ok = usuarioDAO.inserir(usuario);

        if (ok) {
            JOptionPane.showMessageDialog(this, "Usuário cadastrado com sucesso.");
            limparCampos();
            listarTodos();
        }
    }

    private void alterar() {
        if (!exigirMasterNestaTela()) {
            return;
        }
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Selecione um usuário na aba Consulta antes de alterar.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String senhaDigitada = new String(txtSenha.getPassword());
        boolean trocandoSenha = !senhaDigitada.isEmpty();

        if (!validarCampos(trocandoSenha, senhaDigitada)) {
            return;
        }

        int id = Integer.parseInt(txtId.getText());
        String senhaFinal;
        if (trocandoSenha) {
            senhaFinal = senhaDigitada;
        } else {
            Usuario atual = buscarUsuarioAtual(id);
            senhaFinal = atual != null ? atual.getSenha() : "";
        }

        Usuario usuario = montarUsuarioDosCampos(senhaFinal);
        usuario.setIdUsuario(id);

        boolean ok = usuarioDAO.alterar(usuario);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Usuário alterado com sucesso.");
            limparCampos();
            listarTodos();
        }
    }

    private void excluir() {
        if (!exigirMasterNestaTela()) {
            return;
        }
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Selecione um usuário na aba Consulta antes de excluir.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = Integer.parseInt(txtId.getText());

        if (SessaoUsuario.getUsuario() != null && SessaoUsuario.getUsuario().getIdUsuario() == id) {
            JOptionPane.showMessageDialog(this,
                    "Você não pode excluir o usuário com o qual está logado.",
                    "Operação não permitida", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int resposta = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir o usuário \"" + txtNome.getText() + "\"?",
                "Confirmação", JOptionPane.YES_NO_OPTION);

        if (resposta == JOptionPane.YES_OPTION) {
            boolean ok = usuarioDAO.excluir(id);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Usuário excluído com sucesso.");
                limparCampos();
                listarTodos();
            }
        }
    }

    private void listarTodos() {
        preencherTabela(usuarioDAO.listarTodos());
    }

    private void pesquisar() {
        String filtro = (String) cbFiltro.getSelectedItem();
        String texto = txtPesquisa.getText();
        preencherTabela(usuarioDAO.pesquisar(filtro, texto));
    }

    private void preencherTabela(List<Usuario> usuarios) {
        modeloTabela.setRowCount(0);
        for (Usuario u : usuarios) {
            modeloTabela.addRow(new Object[]{
                u.getIdUsuario(), u.getNome(), u.getLogin(), u.getNivel(), u.isAtivo() ? "Sim" : "Não"
            });
        }
    }

    private void carregarSelecionado() {
        int linha = tabela.getSelectedRow();
        txtId.setText(modeloTabela.getValueAt(linha, 0).toString());
        txtNome.setText(String.valueOf(modeloTabela.getValueAt(linha, 1)));
        txtLogin.setText(String.valueOf(modeloTabela.getValueAt(linha, 2)));
        cbNivel.setSelectedItem(String.valueOf(modeloTabela.getValueAt(linha, 3)));
        chkAtivo.setSelected("Sim".equals(modeloTabela.getValueAt(linha, 4)));
        txtSenha.setText("");

        tabbedPane.setSelectedIndex(1);
    }

    private boolean exigirMasterNestaTela() {
        if (!SessaoUsuario.isMaster()) {
            JOptionPane.showMessageDialog(this,
                    "Apenas o usuário MASTER pode administrar outros usuários.",
                    "Acesso negado", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private boolean validarCampos(boolean exigirSenha, String senha) {
        if (txtNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o nome do usuário.",
                    "Campo obrigatório", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        String login = txtLogin.getText().trim();
        if (login.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o login do usuário.",
                    "Campo obrigatório", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (exigirSenha && senha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe a senha do usuário.",
                    "Campo obrigatório", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        Integer idAtual = txtId.getText().isEmpty() ? null : Integer.parseInt(txtId.getText());
        if (usuarioDAO.loginJaExiste(login, idAtual)) {
            JOptionPane.showMessageDialog(this,
                    "Já existe um usuário com este login.",
                    "Login em uso", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return true;
    }

    private Usuario montarUsuarioDosCampos(String senha) {
        Usuario usuario = new Usuario();
        usuario.setNome(txtNome.getText().trim());
        usuario.setLogin(txtLogin.getText().trim());
        usuario.setSenha(senha);
        usuario.setNivel((String) cbNivel.getSelectedItem());
        usuario.setAtivo(chkAtivo.isSelected());
        return usuario;
    }

    private Usuario buscarUsuarioAtual(int id) {
        return usuarioDAO.listarTodos().stream()
                .filter(u -> u.getIdUsuario() == id)
                .findFirst()
                .orElse(null);
    }

    private void limparCampos() {
        txtId.setText("");
        txtNome.setText("");
        txtLogin.setText("");
        txtSenha.setText("");
        cbNivel.setSelectedIndex(0);
        chkAtivo.setSelected(true);
    }
}