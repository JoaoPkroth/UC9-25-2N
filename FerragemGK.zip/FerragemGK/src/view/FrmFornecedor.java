package view;

import dao.FornecedorDAO;
import model.Fornecedor;
import util.Permissao;
import util.Validacao;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrmFornecedor extends javax.swing.JInternalFrame {

    private final FornecedorDAO fornecedorDAO = new FornecedorDAO();
    private DefaultTableModel modeloTabela;

    public FrmFornecedor() {
        initComponents();
        aplicarEstiloVisual();
        setSize(680, 470);
        configurarTabela();
        configurarListeners();
        listarTodos();
    }

    private void aplicarEstiloVisual() {
        java.awt.Color fundo = new java.awt.Color(245, 243, 255);
        java.awt.Color textoLabel = new java.awt.Color(49, 46, 129);
        java.awt.Color headerTabela = new java.awt.Color(67, 56, 202);
        java.awt.Color corPrimaria = new java.awt.Color(79, 70, 229);
        java.awt.Color corPerigo = new java.awt.Color(225, 29, 72);
        java.awt.Color corNeutra = new java.awt.Color(100, 116, 139);

        painelCadastro.setBackground(fundo);
        painelConsulta.setBackground(fundo);
        painelFiltro.setBackground(fundo);
        painelBotoes.setBackground(fundo);
        tabbedPane.setBackground(fundo);

        for (javax.swing.JLabel lbl : new javax.swing.JLabel[]{
            lblId, lblRazaoSocial, lblNomeFantasia, lblCnpj, lblTelefone, lblEmail,
            lblEndereco, lblCidade, lblUf, lblCep, lblFiltro, lblPesquisa}) {
            lbl.setForeground(textoLabel);
            lbl.setFont(lbl.getFont().deriveFont(java.awt.Font.BOLD));
        }

        for (javax.swing.JButton btn : new javax.swing.JButton[]{
            btnNovo, btnSalvar, btnAlterar, btnLocalizar, btnListarTodos}) {
            btn.setBackground(corPrimaria);
            btn.setForeground(java.awt.Color.WHITE);
            btn.setFont(btn.getFont().deriveFont(java.awt.Font.BOLD));
        }
        btnExcluir.setBackground(corPerigo);
        btnExcluir.setForeground(java.awt.Color.WHITE);
        btnExcluir.setFont(btnExcluir.getFont().deriveFont(java.awt.Font.BOLD));
        btnCancelar.setBackground(corNeutra);
        btnCancelar.setForeground(java.awt.Color.WHITE);
        btnCancelar.setFont(btnCancelar.getFont().deriveFont(java.awt.Font.BOLD));

        tabela.getTableHeader().setBackground(headerTabela);
        tabela.getTableHeader().setForeground(java.awt.Color.WHITE);
        tabela.setSelectionBackground(corPrimaria);
        tabela.setSelectionForeground(java.awt.Color.WHITE);
        tabela.setGridColor(new java.awt.Color(237, 233, 254));
    }

    private void configurarTabela() {
        String[] colunas = {"Código", "Razão social", "Fantasia", "CNPJ", "Telefone", "Cidade", "UF", "Ativo"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabela.setModel(modeloTabela);
        tabela.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabela.getSelectedRow() >= 0) {
                carregarSelecionado();
            }
        });
    }

    private void configurarListeners() {
        btnNovo.addActionListener(e -> limparCampos());
        btnSalvar.addActionListener(e -> salvar());
        btnAlterar.addActionListener(e -> alterar());
        btnExcluir.addActionListener(e -> excluir());
        btnCancelar.addActionListener(e -> limparCampos());
        btnLocalizar.addActionListener(e -> pesquisar());
        btnListarTodos.addActionListener(e -> listarTodos());
    }

    private void salvar() {
        if (!validarCampos()) {
            return;
        }
        Fornecedor fornecedor = montarFornecedorDosCampos();
        boolean ok = fornecedorDAO.inserir(fornecedor);

        if (ok) {
            JOptionPane.showMessageDialog(this, "Fornecedor cadastrado com sucesso.");
            limparCampos();
            listarTodos();
        }
    }

    private void alterar() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Selecione um fornecedor na aba Consulta antes de alterar.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!validarCampos()) {
            return;
        }

        Fornecedor fornecedor = montarFornecedorDosCampos();
        fornecedor.setIdFornecedor(Integer.parseInt(txtId.getText()));
        boolean ok = fornecedorDAO.alterar(fornecedor);

        if (ok) {
            JOptionPane.showMessageDialog(this, "Fornecedor alterado com sucesso.");
            limparCampos();
            listarTodos();
        }
    }

    private void excluir() {
        if (!Permissao.exigirMaster()) {
            return;
        }
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Selecione um fornecedor na aba Consulta antes de excluir.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int resposta = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir o fornecedor \"" + txtRazaoSocial.getText() + "\"?",
                "Confirmação", JOptionPane.YES_NO_OPTION);

        if (resposta == JOptionPane.YES_OPTION) {
            boolean ok = fornecedorDAO.excluir(Integer.parseInt(txtId.getText()));
            if (ok) {
                JOptionPane.showMessageDialog(this, "Fornecedor excluído com sucesso.");
                limparCampos();
                listarTodos();
            }
        }
    }

    private void listarTodos() {
        preencherTabela(fornecedorDAO.listarTodos());
    }

    private void pesquisar() {
        String filtro = (String) cbFiltro.getSelectedItem();
        String texto = txtPesquisa.getText();
        preencherTabela(fornecedorDAO.pesquisar(filtro, texto));
    }

    private void preencherTabela(List<Fornecedor> fornecedores) {
        modeloTabela.setRowCount(0);
        for (Fornecedor f : fornecedores) {
            modeloTabela.addRow(new Object[]{
                f.getIdFornecedor(), f.getRazaoSocial(), f.getNomeFantasia(), f.getCnpj(),
                f.getTelefone(), f.getCidade(), f.getUf(), f.isAtivo() ? "Sim" : "Não"
            });
        }
    }

    private void carregarSelecionado() {
        int linha = tabela.getSelectedRow();
        if (linha < 0) {
            return;
        }

        int id = Integer.parseInt(modeloTabela.getValueAt(linha, 0).toString());
        Fornecedor fornecedor = fornecedorDAO.buscarPorId(id);
        if (fornecedor == null) {
            JOptionPane.showMessageDialog(this,
                    "Não foi possível carregar o fornecedor selecionado.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        txtId.setText(String.valueOf(fornecedor.getIdFornecedor()));
        txtRazaoSocial.setText(valorOuVazio(fornecedor.getRazaoSocial()));
        txtNomeFantasia.setText(valorOuVazio(fornecedor.getNomeFantasia()));
        txtCnpj.setText(valorOuVazio(fornecedor.getCnpj()));
        txtTelefone.setText(valorOuVazio(fornecedor.getTelefone()));
        txtEmail.setText(valorOuVazio(fornecedor.getEmail()));
        txtEndereco.setText(valorOuVazio(fornecedor.getEndereco()));
        txtCidade.setText(valorOuVazio(fornecedor.getCidade()));
        txtUf.setText(valorOuVazio(fornecedor.getUf()));
        txtCep.setText(valorOuVazio(fornecedor.getCep()));
        chkAtivo.setSelected(fornecedor.isAtivo());

        tabbedPane.setSelectedIndex(0);
    }

    private String valorOuVazio(String valor) {
        return valor == null ? "" : valor;
    }

    private boolean validarCampos() {
        if (txtRazaoSocial.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe a razão social do fornecedor.",
                    "Campo obrigatório", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (!Validacao.isEmailValido(txtEmail.getText())) {
            JOptionPane.showMessageDialog(this, "O email informado não é válido.",
                    "Email inválido", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private Fornecedor montarFornecedorDosCampos() {
        Fornecedor fornecedor = new Fornecedor();
        fornecedor.setRazaoSocial(txtRazaoSocial.getText().trim());
        fornecedor.setNomeFantasia(txtNomeFantasia.getText().trim());
        fornecedor.setCnpj(txtCnpj.getText().trim());
        fornecedor.setTelefone(txtTelefone.getText().trim());
        fornecedor.setEmail(txtEmail.getText().trim());
        fornecedor.setEndereco(txtEndereco.getText().trim());
        fornecedor.setCidade(txtCidade.getText().trim());
        fornecedor.setUf(txtUf.getText().trim());
        fornecedor.setCep(txtCep.getText().trim());
        fornecedor.setAtivo(chkAtivo.isSelected());
        return fornecedor;
    }

    private void limparCampos() {
        txtId.setText("");
        txtRazaoSocial.setText("");
        txtNomeFantasia.setText("");
        txtCnpj.setText("");
        txtTelefone.setText("");
        txtEmail.setText("");
        txtEndereco.setText("");
        txtCidade.setText("");
        txtUf.setText("");
        txtCep.setText("");
        chkAtivo.setSelected(true);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        tabbedPane = new javax.swing.JTabbedPane();
        painelCadastro = new javax.swing.JPanel();
        lblId = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        lblRazaoSocial = new javax.swing.JLabel();
        txtRazaoSocial = new javax.swing.JTextField();
        lblNomeFantasia = new javax.swing.JLabel();
        txtNomeFantasia = new javax.swing.JTextField();
        lblCnpj = new javax.swing.JLabel();
        txtCnpj = new javax.swing.JTextField();
        lblTelefone = new javax.swing.JLabel();
        txtTelefone = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        lblEndereco = new javax.swing.JLabel();
        txtEndereco = new javax.swing.JTextField();
        lblCidade = new javax.swing.JLabel();
        txtCidade = new javax.swing.JTextField();
        lblUf = new javax.swing.JLabel();
        txtUf = new javax.swing.JTextField();
        lblCep = new javax.swing.JLabel();
        txtCep = new javax.swing.JTextField();
        chkAtivo = new javax.swing.JCheckBox();
        painelBotoes = new javax.swing.JPanel();
        btnNovo = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        btnAlterar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        painelConsulta = new javax.swing.JPanel();
        painelFiltro = new javax.swing.JPanel();
        lblFiltro = new javax.swing.JLabel();
        cbFiltro = new javax.swing.JComboBox();
        lblPesquisa = new javax.swing.JLabel();
        txtPesquisa = new javax.swing.JTextField();
        btnLocalizar = new javax.swing.JButton();
        btnListarTodos = new javax.swing.JButton();
        scrollTabela = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Fornecedores");

        painelCadastro.setLayout(new java.awt.GridBagLayout());

        lblId.setText("Código:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblId, gridBagConstraints);

        txtId.setColumns(5);
        txtId.setEditable(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtId, gridBagConstraints);

        lblRazaoSocial.setText("Razão social:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblRazaoSocial, gridBagConstraints);

        txtRazaoSocial.setColumns(28);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtRazaoSocial, gridBagConstraints);

        lblNomeFantasia.setText("Nome fantasia:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblNomeFantasia, gridBagConstraints);

        txtNomeFantasia.setColumns(25);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtNomeFantasia, gridBagConstraints);

        lblCnpj.setText("CNPJ:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblCnpj, gridBagConstraints);

        txtCnpj.setColumns(18);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtCnpj, gridBagConstraints);

        lblTelefone.setText("Telefone:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblTelefone, gridBagConstraints);

        txtTelefone.setColumns(15);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtTelefone, gridBagConstraints);

        lblEmail.setText("Email:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblEmail, gridBagConstraints);

        txtEmail.setColumns(25);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtEmail, gridBagConstraints);

        lblEndereco.setText("Endereço:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblEndereco, gridBagConstraints);

        txtEndereco.setColumns(25);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtEndereco, gridBagConstraints);

        lblCidade.setText("Cidade:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblCidade, gridBagConstraints);

        txtCidade.setColumns(20);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtCidade, gridBagConstraints);

        lblUf.setText("UF:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblUf, gridBagConstraints);

        txtUf.setColumns(2);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtUf, gridBagConstraints);

        lblCep.setText("CEP:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 9;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(lblCep, gridBagConstraints);

        txtCep.setColumns(10);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 9;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(txtCep, gridBagConstraints);

        chkAtivo.setSelected(true);
        chkAtivo.setText("Ativo");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(chkAtivo, gridBagConstraints);

        painelBotoes.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnNovo.setText("Novo");
        painelBotoes.add(btnNovo);

        btnSalvar.setText("Salvar");
        painelBotoes.add(btnSalvar);

        btnAlterar.setText("Alterar");
        painelBotoes.add(btnAlterar);

        btnExcluir.setText("Excluir");
        painelBotoes.add(btnExcluir);

        btnCancelar.setText("Cancelar");
        painelBotoes.add(btnCancelar);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 11;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        painelCadastro.add(painelBotoes, gridBagConstraints);

        tabbedPane.addTab("Cadastro", painelCadastro);

        painelConsulta.setLayout(new java.awt.BorderLayout());

        painelFiltro.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));

        lblFiltro.setText("Filtro:");
        painelFiltro.add(lblFiltro);

        cbFiltro.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "RAZAO", "FANTASIA", "ID", "CNPJ" }));
        painelFiltro.add(cbFiltro);

        lblPesquisa.setText("Pesquisa:");
        painelFiltro.add(lblPesquisa);

        txtPesquisa.setColumns(15);
        painelFiltro.add(txtPesquisa);

        btnLocalizar.setText("Localizar");
        painelFiltro.add(btnLocalizar);

        btnListarTodos.setText("Listar todos");
        painelFiltro.add(btnListarTodos);

        painelConsulta.add(painelFiltro, java.awt.BorderLayout.NORTH);

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Razão social", "Fantasia", "CNPJ", "Telefone", "Cidade", "UF", "Ativo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        scrollTabela.setViewportView(tabela);

        painelConsulta.add(scrollTabela, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Consulta", painelConsulta);

        getContentPane().add(tabbedPane, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnListarTodos;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JComboBox cbFiltro;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JLabel lblCep;
    private javax.swing.JLabel lblCidade;
    private javax.swing.JLabel lblCnpj;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblEndereco;
    private javax.swing.JLabel lblFiltro;
    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblNomeFantasia;
    private javax.swing.JLabel lblPesquisa;
    private javax.swing.JLabel lblRazaoSocial;
    private javax.swing.JLabel lblTelefone;
    private javax.swing.JLabel lblUf;
    private javax.swing.JPanel painelBotoes;
    private javax.swing.JPanel painelCadastro;
    private javax.swing.JPanel painelConsulta;
    private javax.swing.JPanel painelFiltro;
    private javax.swing.JScrollPane scrollTabela;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JTable tabela;
    private javax.swing.JTextField txtCep;
    private javax.swing.JTextField txtCidade;
    private javax.swing.JTextField txtCnpj;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtNomeFantasia;
    private javax.swing.JTextField txtPesquisa;
    private javax.swing.JTextField txtRazaoSocial;
    private javax.swing.JTextField txtTelefone;
    private javax.swing.JTextField txtUf;
    // End of variables declaration//GEN-END:variables
}