package service;

import conexao.Conexao;
import dao.CompraDAO;
import dao.ContaPagarDAO;
import model.Compra;
import model.ContaPagar;
import model.ProdutoCompra;
import java.util.List;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class CompraService {

    private final CompraDAO compraDAO = new CompraDAO();
    private final ContaPagarDAO contaPagarDAO = new ContaPagarDAO();

    public boolean finalizarCompra(Compra compra) {
        Connection conexao = null;

        try {
            conexao = Conexao.conectar();
            if (conexao == null) {
                return false;
            }
            conexao.setAutoCommit(false);

            compra.setStatus("FINALIZADA");

            compraDAO.inserir(conexao, compra);

            compraDAO.inserirItens(conexao, compra);

            for (ProdutoCompra item : compra.getItens()) {
                compraDAO.atualizarEstoque(conexao, item);
            }

            gerarContasPagar(conexao, compra);

            conexao.commit();
            return true;

        } catch (SQLException e) {
            desfazer(conexao);
            JOptionPane.showMessageDialog(null,
                    "Erro ao finalizar a compra. Nenhuma informação foi gravada.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;

        } finally {
            Conexao.fechar(conexao);
        }
    }

    public boolean cancelarCompra(int idCompra) {
        Connection conexao = null;

        try {
            conexao = Conexao.conectar();
            if (conexao == null) {
                return false;
            }
            conexao.setAutoCommit(false);

            List<ProdutoCompra> itens = compraDAO.listarItens(idCompra);
            for (ProdutoCompra item : itens) {
                compraDAO.reverterEstoque(conexao, item);
            }

            contaPagarDAO.cancelarPorCompra(conexao, idCompra);
            compraDAO.cancelar(conexao, idCompra);

            conexao.commit();
            return true;

        } catch (SQLException e) {
            desfazer(conexao);
            JOptionPane.showMessageDialog(null,
                    "Erro ao cancelar a compra. Nenhuma informação foi alterada.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;

        } finally {
            Conexao.fechar(conexao);
        }
    }

    private void desfazer(Connection conexao) {
        try {
            if (conexao != null) {
                conexao.rollback();
            }
        } catch (SQLException ex) {
        }
    }

    private void gerarContasPagar(Connection conexao, Compra compra) throws SQLException {
        boolean aVista = "A VISTA".equalsIgnoreCase(compra.getFormaPagamento());
        int parcelas = aVista ? 1 : Math.max(compra.getQuantidadeParcelas(), 1);

        BigDecimal valorParcela = compra.getValorTotal()
                .divide(BigDecimal.valueOf(parcelas), 2, RoundingMode.HALF_UP);
        BigDecimal somaParcelas = BigDecimal.ZERO;

        for (int numero = 1; numero <= parcelas; numero++) {
            ContaPagar conta = new ContaPagar();
            conta.setIdCompra(compra.getIdCompra());
            conta.setNumeroParcela(numero);
            conta.setDataEmissao(compra.getDataCompra());
            conta.setDataVencimento(aVista ? compra.getDataCompra() : compra.getDataCompra().plusMonths(numero));
            conta.setStatus("ABERTA");

            BigDecimal valor = (numero == parcelas)
                    ? compra.getValorTotal().subtract(somaParcelas)
                    : valorParcela;
            somaParcelas = somaParcelas.add(valor);
            conta.setValorParcela(valor);

            contaPagarDAO.inserir(conexao, conta);
        }
    }
}