package service;

import conexao.Conexao;
import dao.ContaReceberDAO;
import dao.VendaDAO;
import model.ContaReceber;
import model.ProdutoVenda;
import model.Venda;
import java.util.List;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class VendaService {

    private final VendaDAO vendaDAO = new VendaDAO();
    private final ContaReceberDAO contaReceberDAO = new ContaReceberDAO();

    public boolean finalizarVenda(Venda venda) {
        Connection conexao = null;

        try {
            conexao = Conexao.conectar();
            if (conexao == null) {
                return false;
            }
            conexao.setAutoCommit(false);

            venda.setStatus("FINALIZADA");

            vendaDAO.inserir(conexao, venda);

            vendaDAO.inserirItens(conexao, venda);

            for (ProdutoVenda item : venda.getItens()) {
                vendaDAO.baixarEstoque(conexao, item);
            }

            gerarContasReceber(conexao, venda);

            conexao.commit();
            return true;

        } catch (SQLException e) {
            desfazer(conexao);
            JOptionPane.showMessageDialog(null,
                    "Erro ao finalizar a venda. Nenhuma informação foi gravada.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;

        } finally {
            Conexao.fechar(conexao);
        }
    }

    public boolean cancelarVenda(int idVenda) {
        Connection conexao = null;

        try {
            conexao = Conexao.conectar();
            if (conexao == null) {
                return false;
            }
            conexao.setAutoCommit(false);

            List<ProdutoVenda> itens = vendaDAO.listarItens(idVenda);
            for (ProdutoVenda item : itens) {
                vendaDAO.devolverEstoque(conexao, item);
            }

            contaReceberDAO.cancelarPorVenda(conexao, idVenda);
            vendaDAO.cancelar(conexao, idVenda);

            conexao.commit();
            return true;

        } catch (SQLException e) {
            desfazer(conexao);
            JOptionPane.showMessageDialog(null,
                    "Erro ao cancelar a venda. Nenhuma informação foi alterada.\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return false;

        } finally {
            Conexao.fechar(conexao);
        }
    }

    private void desfazer(Connection conexao) {
        try {
            if (conexao != null) {
                conexao.rollback();
            }
        } catch (SQLException ex) {
        }
    }

    private void gerarContasReceber(Connection conexao, Venda venda) throws SQLException {
        boolean aVista = "A VISTA".equalsIgnoreCase(venda.getFormaPagamento());
        int parcelas = aVista ? 1 : Math.max(venda.getQuantidadeParcelas(), 1);

        BigDecimal valorParcela = venda.getValorTotal()
                .divide(BigDecimal.valueOf(parcelas), 2, RoundingMode.HALF_UP);
        BigDecimal somaParcelas = BigDecimal.ZERO;

        for (int numero = 1; numero <= parcelas; numero++) {
            ContaReceber conta = new ContaReceber();
            conta.setIdVenda(venda.getIdVenda());
            conta.setNumeroParcela(numero);
            conta.setDataEmissao(venda.getDataVenda());
            conta.setDataVencimento(aVista ? venda.getDataVenda() : venda.getDataVenda().plusMonths(numero));
            conta.setStatus("ABERTA");

            BigDecimal valor = (numero == parcelas)
                    ? venda.getValorTotal().subtract(somaParcelas)
                    : valorParcela;
            somaParcelas = somaParcelas.add(valor);
            conta.setValorParcela(valor);

            contaReceberDAO.inserir(conexao, conta);
        }
    }
}